# Guía de Conexión en la Nube con Google Drive y Google Sheets
## GEOCIENCES S.A.C.

Esta guía te permite conectar la aplicación móvil directamente con tu Google Drive y Google Sheets mediante **Google Apps Script** (Opción 1).

---

### Paso 1: Abrir Google Sheets
1. Entra a tu carpeta de Google Drive:
   - Para GERENTE: https://drive.google.com/drive/folders/14PXZAAEWLZnqpADsRmVtzaY4ptFpajag
   - O crea una nueva hoja de cálculo llamada **GEOCIENCES_DATABASE_PRINCIPAL**.

### Paso 2: Abrir Apps Script
1. En el menú superior de la hoja de cálculo, haz clic en **Extensiones** > **Apps Script**.

### Paso 3: Pegar el Código
1. Borra todo el código que aparezca en el editor (`function myFunction() { ... }`).
2. Abre el archivo `google-apps-script/Code.gs` o cópialo directamente desde la aplicación móvil (Menú > **7. NUBE & DRIVE** > pestaña **CÓDIGO .GS** > botón **COPIAR CÓDIGO**).
3. Pega el código completo y presiona el ícono del disquete (Guardar).

### Paso 4: Implementar como Aplicación Web
1. Haz clic en el botón azul **Implementar** (arriba a la derecha) y selecciona **Nueva implementación**.
2. Haz clic en el ícono de engranaje (⚙️) junto a "Seleccionar tipo" y elige **Aplicación web**.
3. Llena los campos:
   - **Descripción**: `GEOCIENCES Sync Webhook v1`
   - **Ejecutar como**: `Yo (tu cuenta de Google)`
   - **Quién tiene acceso**: `Cualquier usuario` (Esto es fundamental para que el celular envíe los datos sin bloqueo de autenticación de navegador).
4. Haz clic en **Implementar**.
5. Si Google solicita permisos ("Autorizar acceso"), haz clic en tu cuenta, luego en "Configuración avanzada" (Advanced) y en "Ir a GEOCIENCES Webhook (no seguro)" para conceder los permisos de escritura a tu propia hoja de cálculo.

### Paso 5: Vincular en la Aplicación Móvil
1. Copia la **URL de la aplicación web** generada (termina en `/exec`).
2. En la aplicación móvil, abre el menú lateral o toca el ícono de la nube en la barra superior.
3. Ve a la pestaña **WEBHOOK** y pega la URL.
4. Presiona **GUARDAR URL** y luego **PROBAR**.
5. ¡Listo! A partir de ese momento, cualquier cambio de proyecto, fila de Excel, marcación GPS o perfil se sincronizará automáticamente con tu Google Sheets en la nube.

/**
 * ====================================================================
 * GEOCIENCES S.A.C. - Google Apps Script Cloud Sync Webhook
 * Automatización de sincronización con Google Drive y Google Sheets
 * ====================================================================
 * 
 * INSTRUCCIONES DE INSTALACIÓN:
 * 1. Abre tu Google Drive y abre o crea tu Google Sheets principal.
 * 2. En el menú superior, ve a: Extensiones -> Apps Script.
 * 3. Borra el código existente y pega TODO este archivo.
 * 4. Haz clic en "Implementar" (arriba a la derecha) -> "Nueva implementación".
 * 5. Selecciona tipo: "Aplicación web".
 * 6. Configura:
 *    - Descripción: "GEOCIENCES App Sync Webhook"
 *    - Ejecutar como: "Yo" (tu cuenta de Google)
 *    - Quién tiene acceso: "Cualquier usuario" (Anyone)
 * 7. Haz clic en "Implementar" y autoriza los permisos si te los pide.
 * 8. Copia la "URL de la aplicación web" (termina en /exec) y pégala
 *    en la app móvil en: Menú -> Nube & Sincronización -> Webhook URL.
 */

function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(15000);
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return respondJSON({ status: 'error', message: 'No se recibieron datos' });
    }

    var payload = JSON.parse(e.postData.contents);
    var action = payload.action || 'sync_all';
    var role = payload.role || 'GENERAL';
    var userEmail = payload.user || 'usuario@geociences.pe';
    var ss = SpreadsheetApp.getActiveSpreadsheet();

    // 1. Hoja de Historial de Auditoría (LOGS)
    var logSheet = ss.getSheetByName('LOG_SINCRONIZACION');
    if (!logSheet) {
      logSheet = ss.insertSheet('LOG_SINCRONIZACION');
      logSheet.appendRow(['FECHA Y HORA', 'USUARIO', 'CARGO', 'ACCIÓN', 'ESTADO', 'REGISTROS']);
      logSheet.getRange('A1:F1').setBackground('#0B132B').setFontColor('#FFFFFF').setFontWeight('bold');
    }
    
    // 2. Procesar según la acción
    if (action === 'sync_items' || action === 'sync_all') {
      if (payload.items && payload.items.length >= 0) {
        var sheetName = 'REGISTROS_' + role;
        var itemSheet = ss.getSheetByName(sheetName) || ss.insertSheet(sheetName);
        itemSheet.clear();
        itemSheet.appendRow(['ID', 'CARGO', 'NOMBRE / PROYECTO / PERSONAL', 'ESTADO', 'ÚLTIMA MODIFICACIÓN']);
        itemSheet.getRange('A1:E1').setBackground('#1E293B').setFontColor('#FFFFFF').setFontWeight('bold');
        
        payload.items.forEach(function(item) {
          itemSheet.appendRow([
            item.id || '',
            role,
            item.name || '',
            item.status || 'Activo',
            item.updatedAt || new Date().toISOString()
          ]);
        });
      }
    }

    if (action === 'sync_sheet' || action === 'sync_all') {
      if (payload.sheets && payload.sheets.length >= 0) {
        var excelSheetName = 'CALCULO_' + role;
        var exSheet = ss.getSheetByName(excelSheetName) || ss.insertSheet(excelSheetName);
        exSheet.clear();
        
        if (payload.sheets.length > 0) {
          var firstRow = payload.sheets[0];
          var headers = Object.keys(firstRow).filter(function(k) { return k !== 'id'; });
          exSheet.appendRow(['ID_FILA'].concat(headers));
          exSheet.getRange(1, 1, 1, headers.length + 1).setBackground('#0F172A').setFontColor('#38BDF8').setFontWeight('bold');
          
          payload.sheets.forEach(function(row) {
            var rowData = [row.id || ''];
            headers.forEach(function(h) {
              rowData.push(row[h] !== undefined ? row[h] : '');
            });
            exSheet.appendRow(rowData);
          });
        }
      }
    }

    if (action === 'save_gps') {
      if (payload.gps) {
        var gpsSheet = ss.getSheetByName('REGISTROS_GPS');
        if (!gpsSheet) {
          gpsSheet = ss.insertSheet('REGISTROS_GPS');
          gpsSheet.appendRow(['FECHA Y HORA', 'USUARIO', 'CARGO', 'LATITUD', 'LONGITUD', 'PRECISIÓN (m)', 'PROYECTO', 'NOTAS']);
          gpsSheet.getRange('A1:H1').setBackground('#064E3B').setFontColor('#FFFFFF').setFontWeight('bold');
        }
        var g = payload.gps;
        gpsSheet.appendRow([
          g.timestamp || new Date().toISOString(),
          g.userName || userEmail,
          g.role || role,
          g.latitude,
          g.longitude,
          g.accuracy,
          g.projectName || '',
          g.notes || ''
        ]);
      }
    }

    logSheet.appendRow([
      new Date().toLocaleString('es-PE'),
      userEmail,
      role,
      action,
      'EXITOSO',
      'Sincronizado correctamente'
    ]);

    return respondJSON({
      status: 'success',
      message: 'Sincronizado con éxito en Google Sheets & Drive',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    return respondJSON({
      status: 'error',
      message: error.toString()
    });
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  return respondJSON({
    service: 'GEOCIENCES S.A.C. Sync API',
    status: 'online',
    version: '1.2.0',
    driveSync: true,
    timestamp: new Date().toISOString()
  });
}

function respondJSON(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

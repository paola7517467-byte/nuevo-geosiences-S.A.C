import { UserRole, ListItem, SheetColumn, SheetRow, RoleResponsibility } from '../types';

export const WHATSAPP_URL = 'https://chat.whatsapp.com/IfDos243VUP8xzd0Tv6u7T?s=cl&p=a&iam=2';

export const DRIVE_CONFIG: Record<UserRole, {
  mainFolder: string;
  excelFolder: string;
  menuDriveFolder: string;
  name: string;
  label: string;
  theme: {
    bg: string;
    headerBg: string;
    text: string;
    accent: string;
    cardBg: string;
    border: string;
  };
}> = {
  GERENTE: {
    mainFolder: 'https://drive.google.com/drive/folders/12vwQupCEab9IW8GfBjGtt8IYULnNFHe5?usp=drive_link',
    excelFolder: 'https://drive.google.com/drive/folders/14PXZAAEWLZnqpADsRmVtzaY4ptFpajag?usp=drive_link',
    menuDriveFolder: 'https://drive.google.com/drive/folders/183ypBi1mbiVwISN91GnzHPVPhQRwwHSn?usp=sharing',
    name: 'Proyectos Estratégicos',
    label: 'GERENTE GENERAL',
    theme: {
      bg: 'bg-black text-white',
      headerBg: 'bg-neutral-950 border-b border-neutral-800 text-white',
      text: 'text-white',
      accent: 'bg-blue-600 hover:bg-blue-500 text-white',
      cardBg: 'bg-neutral-900 border-neutral-800',
      border: 'border-neutral-800',
    },
  },
  ADMINISTRADOR: {
    mainFolder: 'https://drive.google.com/drive/folders/16HKzbRHthYxBbR0gc-ZPUP3c90ftx7dm?usp=sharing',
    excelFolder: 'https://drive.google.com/drive/folders/1XJDeAsDzk_cYDi4tpfR2oRTJGm01IJ9D?usp=sharing',
    menuDriveFolder: 'https://drive.google.com/drive/folders/1n5_nzg23lMnRlG3X4z8wgg3jrokyeP-v?usp=sharing',
    name: 'Personal y Colaboradores',
    label: 'ADMINISTRADOR DE EMPRESA',
    theme: {
      bg: 'bg-slate-800 text-slate-100',
      headerBg: 'bg-slate-900 border-b border-slate-700 text-slate-100',
      text: 'text-slate-100',
      accent: 'bg-slate-700 hover:bg-slate-600 text-white',
      cardBg: 'bg-slate-900/90 border-slate-700',
      border: 'border-slate-700',
    },
  },
  RESIDENTE: {
    mainFolder: 'https://drive.google.com/drive/folders/1SNQALKRa4MAWm4rZtu2LekQsMpu-LwoV?usp=sharing',
    excelFolder: 'https://drive.google.com/drive/folders/1WMX96ERMnW52yCqPMtu3bgC88F4GL1cv?usp=sharing',
    menuDriveFolder: 'https://drive.google.com/drive/folders/1n0Xi_6tTD6zBNLOaNKvzmT5KVL2byfPR?usp=sharing',
    name: 'Proyectos y Control de Obra',
    label: 'INGENIERO RESIDENTE',
    theme: {
      bg: 'bg-sky-950 text-white',
      headerBg: 'bg-sky-900 border-b border-sky-800 text-white',
      text: 'text-white',
      accent: 'bg-sky-600 hover:bg-sky-500 text-white',
      cardBg: 'bg-sky-900/80 border-sky-800',
      border: 'border-sky-800',
    },
  },
  OBRERO: {
    mainFolder: 'https://drive.google.com/drive/folders/1HQRnfV-qfg9bzP2YoNtg6aWnG8_-xHK1?usp=sharing',
    excelFolder: 'https://drive.google.com/drive/folders/1qBaxMP0Sp1TtNAWCeP4W6M_JBVgq6exH?usp=sharing',
    menuDriveFolder: 'https://drive.google.com/drive/folders/16tMDzhLyCtoxPrnwGrET-E9CyMXUg6Gj?usp=sharing',
    name: 'Trabajos y Actividades en Campo',
    label: 'OBRERO / OPERADOR TÉCNICO',
    theme: {
      bg: 'bg-sky-50 text-slate-900',
      headerBg: 'bg-sky-200 border-b border-sky-300 text-slate-900',
      text: 'text-slate-900',
      accent: 'bg-sky-600 hover:bg-sky-700 text-white',
      cardBg: 'bg-white border-sky-200 shadow-sm',
      border: 'border-sky-200',
    },
  },
};

export const INITIAL_ITEMS: Record<UserRole, ListItem[]> = {
  GERENTE: [
    {
      id: 'proj-01',
      name: 'Estudio Geotécnico y Mecánica de Suelos - Carretera Central Km 42',
      code: 'GEO-PRJ-2026-001',
      role: 'GERENTE',
      status: 'activo',
      category: 'Infraestructura Vial',
      details: 'Sondajes SPT de 15m, ensayos triaxiales y consolidación unidimensional para puente vehicular.',
      location: 'Chosica - Huarochirí',
      responsible: 'Ing. Carlos Mendoza (CIP 189201)',
      updatedAt: '2026-11-08 16:30',
    },
    {
      id: 'proj-02',
      name: 'Estabilidad de Taludes y Microzonificación Sísmica - Pasamayito',
      code: 'GEO-PRJ-2026-002',
      role: 'GERENTE',
      status: 'en_progreso',
      category: 'Geotecnia Aplicada',
      details: 'Modelamiento con Slide/GeoStudio, análisis de equilibrio límite y diseño de banquetas de corte.',
      location: 'Comas - San Juan de Lurigancho',
      responsible: 'Ing. Fernando Rios (CIP 203411)',
      updatedAt: '2026-11-07 11:20',
    },
    {
      id: 'proj-03',
      name: 'Supervisión Geotécnica Presa de Relaves Minera Huallanca',
      code: 'GEO-PRJ-2026-003',
      role: 'GERENTE',
      status: 'activo',
      category: 'Minería & Presas',
      details: 'Control piezométrico con cuerda vibrante, densidad nuclear e inclinometría quincenal.',
      location: 'Áncash - Huallanca',
      responsible: 'Ing. Marco Valdivia (CIP 145980)',
      updatedAt: '2026-11-06 09:45',
    },
    {
      id: 'proj-04',
      name: 'Levantamiento Topográfico y Batimetría Cuenca Baja Río Rímac',
      code: 'GEO-PRJ-2026-004',
      role: 'GERENTE',
      status: 'completado',
      category: 'Hidráulica y Topografía',
      details: 'Ecosonda digital monohaz y dron RTK con 12 puntos de control geodésico de orden B.',
      location: 'Callao - Lima',
      responsible: 'Ing. Patricia Luna (CIP 221094)',
      updatedAt: '2026-11-05 18:00',
    },
  ],
  ADMINISTRADOR: [
    {
      id: 'adm-01',
      name: 'Ing. Carlos Mendoza Paredes - Especialista Geotécnico Senior',
      code: 'EMP-GEO-001',
      role: 'ADMINISTRADOR',
      status: 'activo',
      category: 'Ingeniería',
      details: 'CIP 189201. Maestría en Geotecnia UNI. 12 años de experiencia en cimentaciones profundas.',
      location: 'Oficina Central / Obra Chosica',
      responsible: 'Recursos Humanos',
      updatedAt: '2026-11-08 14:10',
    },
    {
      id: 'adm-02',
      name: 'Roberto Quispe Huamán - Topógrafo Principal de Campo',
      code: 'EMP-GEO-002',
      role: 'ADMINISTRADOR',
      status: 'activo',
      category: 'Topografía',
      details: 'Especialista en Estación Total Leica TS07 y GPS Geodésico Diferencial CHCNAV i73.',
      location: 'Frente de Obra Pasamayito',
      responsible: 'Recursos Humanos',
      updatedAt: '2026-11-07 10:30',
    },
    {
      id: 'adm-03',
      name: 'Andrea Morales Salazar - Analista de Laboratorio de Mecánica de Suelos',
      code: 'EMP-GEO-003',
      role: 'ADMINISTRADOR',
      status: 'activo',
      category: 'Laboratorio',
      details: 'Supervisión de ensayos ASTM D422 (Granulometría), ASTM D4318 (Atterberg) y CBR.',
      location: 'Laboratorio Central GEOCIENCES',
      responsible: 'Recursos Humanos',
      updatedAt: '2026-11-06 17:00',
    },
    {
      id: 'adm-04',
      name: 'José Flores Cárdenas - Conductor Operador de Camioneta 4x4 y Logística',
      code: 'EMP-GEO-004',
      role: 'ADMINISTRADOR',
      status: 'activo',
      category: 'Operaciones',
      details: 'Licencia A-IIb vigente con curso de manejo defensivo en mina y primeros auxilios.',
      location: 'Unidad Móvil N° 3',
      responsible: 'Logística',
      updatedAt: '2026-11-05 08:20',
    },
  ],
  RESIDENTE: [
    {
      id: 'res-01',
      name: 'Perforación Diamantina y Ensayo SPT - Sondaje S-03 (0 a 15.00m)',
      code: 'RES-ACT-001',
      role: 'RESIDENTE',
      status: 'en_progreso',
      category: 'Perforación',
      details: 'Extracción de testigos HQ3 con porcentaje de recuperación RQD 82%. Nivel freático a 4.20m.',
      location: 'Progresiva 02+450',
      responsible: 'Ing. Residente de Obra',
      updatedAt: '2026-11-08 15:40',
    },
    {
      id: 'res-02',
      name: 'Apertura de Calicatas a Cielo Abierto C-04 a C-08 (Prof. 2.50m)',
      code: 'RES-ACT-002',
      role: 'RESIDENTE',
      status: 'activo',
      category: 'Exploración',
      details: 'Muestreo de suelo distorsionado e inalterado en bloques según norma NTP 339.151.',
      location: 'Sector Terraplén 1',
      responsible: 'Ing. Residente de Obra',
      updatedAt: '2026-11-07 16:15',
    },
    {
      id: 'res-03',
      name: 'Control de Densidad In Situ Método Cono de Arena - Capa Base 2',
      code: 'RES-ACT-003',
      role: 'RESIDENTE',
      status: 'completado',
      category: 'Control de Calidad',
      details: 'Grado de compactación verificado al 98.4% del Proctor Modificado ASTM D1557.',
      location: 'Plataforma Sub-balasto',
      responsible: 'Ing. Residente de Obra',
      updatedAt: '2026-11-06 12:00',
    },
    {
      id: 'res-04',
      name: 'Instalación de Piezómetros Casagrande en Talud Sector Este',
      code: 'RES-ACT-004',
      role: 'RESIDENTE',
      status: 'pendiente',
      category: 'Instrumentación',
      details: 'Filtro de arena Ottawa calibrada y sello de bentonita expandida de 60cm de espesor.',
      location: 'Estación Talud Crítico',
      responsible: 'Ing. Residente de Obra',
      updatedAt: '2026-11-05 14:30',
    },
  ],
  OBRERO: [
    {
      id: 'obr-01',
      name: 'Excavación Manual y Perfilado de Calicata C-05 (1.50 x 1.50 x 2.20 m)',
      code: 'OBR-TRB-001',
      role: 'OBRERO',
      status: 'en_progreso',
      category: 'Excavaciones',
      details: 'Zanja con apuntalamiento perimetral, línea de vida, escalera de escape y malla naranja.',
      location: 'Sector A - Calicata 5',
      responsible: 'Cuadrilla de Campo N° 1',
      updatedAt: '2026-11-08 11:00',
    },
    {
      id: 'obr-02',
      name: 'Envasado y Rotulado de Muestras de Suelo (Costales Herméticos 40 kg)',
      code: 'OBR-TRB-002',
      role: 'OBRERO',
      status: 'activo',
      category: 'Muestreo',
      details: 'Doble bolsa de polietileno con tarjeta plastificada de identificación de estrato.',
      location: 'Estación de Muestreo 2',
      responsible: 'Cuadrilla de Campo N° 2',
      updatedAt: '2026-11-07 15:30',
    },
    {
      id: 'obr-03',
      name: 'Limpieza, Señalización y Mantenimiento de Talud de Seguridad',
      code: 'OBR-TRB-003',
      role: 'OBRERO',
      status: 'completado',
      category: 'Seguridad SSOMA',
      details: 'Retiro de material suelto en coronación de talud y colocación de conos reflectivos.',
      location: 'Acceso Principal Frente 3',
      responsible: 'Cuadrilla de Limpieza',
      updatedAt: '2026-11-06 17:10',
    },
    {
      id: 'obr-04',
      name: 'Traslado y Almacenaje Seguro de Equipo CPTu y Varillaje SPT',
      code: 'OBR-TRB-004',
      role: 'OBRERO',
      status: 'activo',
      category: 'Equipos y Herramientas',
      details: 'Aseguramiento con eslingas certificadas en plataforma y verificación de mordazas.',
      location: 'Almacén de Obra',
      responsible: 'Cuadrilla de Logística',
      updatedAt: '2026-11-05 16:45',
    },
  ],
};

export const SHEET_COLUMNS: Record<UserRole, SheetColumn[]> = {
  GERENTE: [
    { key: 'proyecto', label: 'PROYECTO / HITO', width: '240px' },
    { key: 'presupuesto', label: 'PRESUPUESTO S/.', width: '150px' },
    { key: 'avance', label: 'AVANCE (%)', width: '120px' },
    { key: 'responsable', label: 'RESPONSABLE', width: '180px' },
    { key: 'estadoFinanciero', label: 'ESTADO FINANCIERO', width: '160px' },
    { key: 'observaciones', label: 'OBSERVACIONES', width: '260px' },
  ],
  ADMINISTRADOR: [
    { key: 'postulante', label: 'POSTULANTE', width: '220px' },
    { key: 'cargo', label: 'CARGO', width: '180px' },
    { key: 'equipo', label: 'EQUIPO', width: '160px' },
    { key: 'curriculum', label: 'CURRÍCULUM', width: '150px' },
    { key: 'entrevistador', label: 'ENTREVISTADOR', width: '180px' },
    { key: 'nota', label: 'NOTA', width: '100px' },
  ],
  RESIDENTE: [
    { key: 'tarea', label: 'TAREA', width: '220px' },
    { key: 'prioritario', label: 'PRIORITARIO', width: '130px' },
    { key: 'estado', label: 'ESTADO', width: '140px' },
    { key: 'fecha', label: 'FECHA', width: '130px' },
    { key: 'logro', label: 'LOGRO', width: '200px' },
    { key: 'productoFinal', label: 'PRODUCTO FINAL', width: '220px' },
  ],
  OBRERO: [
    { key: 'objetivos', label: 'OBJETIVOS', width: '230px' },
    { key: 'prioridad', label: 'PRIORIDAD', width: '130px' },
    { key: 'propietario', label: 'PROPIETARIO', width: '180px' },
    { key: 'estado', label: 'ESTADO', width: '140px' },
    { key: 'fechaInicio', label: 'FECHA DE INICIO', width: '140px' },
  ],
};

export const INITIAL_SHEET_DATA: Record<UserRole, SheetRow[]> = {
  GERENTE: [
    { id: 'g-row-1', proyecto: 'Carretera Central Km 42 - Mecánica Suelos', presupuesto: 'S/. 185,000.00', avance: '85%', responsable: 'Ing. Carlos Mendoza', estadoFinanciero: 'Al día - Val. 3', observaciones: 'Entregable final programado para viernes.' },
    { id: 'g-row-2', proyecto: 'Estabilidad de Taludes Pasamayito', presupuesto: 'S/. 120,000.00', avance: '60%', responsable: 'Ing. Fernando Rios', estadoFinanciero: 'Anticipo cobrado 40%', observaciones: 'Pendiente informe de microzonificación.' },
    { id: 'g-row-3', proyecto: 'Presa de Relaves Minera Huallanca', presupuesto: 'S/. 340,000.00', avance: '40%', responsable: 'Ing. Marco Valdivia', estadoFinanciero: 'Val. 2 en trámite', observaciones: 'Monitoreo de inclinómetros sin alertas.' },
    { id: 'g-row-4', proyecto: 'Batimetría Río Rímac Cuenca Baja', presupuesto: 'S/. 95,000.00', avance: '100%', responsable: 'Ing. Patricia Luna', estadoFinanciero: 'Liquidado 100%', observaciones: 'Acta de recepción firmada sin observaciones.' },
  ],
  ADMINISTRADOR: [
    { id: 'a-row-1', postulante: 'Erick Dávila Rojas', cargo: 'Ingeniero Geotécnico Junior', equipo: 'Suelos y Cimentaciones', curriculum: 'CV-ED-2026.pdf (Aprobado)', entrevistador: 'Lic. Claudia Benavides', nota: '18.5' },
    { id: 'a-row-2', postulante: 'Marcos Vilca Quispe', cargo: 'Operador de Perforadora Diamantina', equipo: 'Sondajes Campo', curriculum: 'CV-MV-2026.pdf (Aprobado)', entrevistador: 'Ing. Residente Rios', nota: '17.0' },
    { id: 'a-row-3', postulante: 'Sofía Cáceres Ramos', cargo: 'Técnica de Laboratorio de Suelos', equipo: 'Control de Calidad', curriculum: 'CV-SC-2026.pdf (Revisión)', entrevistador: 'Lic. Claudia Benavides', nota: '16.0' },
    { id: 'a-row-4', postulante: 'Raúl Huanca Perez', cargo: 'Topógrafo de Obra', equipo: 'Topografía y Geodesia', curriculum: 'CV-RH-2026.pdf (Aprobado)', entrevistador: 'Ing. Patricia Luna', nota: '19.0' },
  ],
  RESIDENTE: [
    { id: 'r-row-1', tarea: 'Perforación diamantina sondaje SPT-03', prioritario: 'Alta', estado: 'En Progreso', fecha: '2026-11-08', logro: '12.5m perforados de 15.0m', productoFinal: 'Registro estratigráfico preliminar' },
    { id: 'r-row-2', tarea: 'Apertura calicatas C-04 a C-08', prioritario: 'Media', estado: 'Completado', fecha: '2026-11-07', logro: '5 calicatas a 2.50m perfiladas', productoFinal: 'Muestras rotuladas en laboratorio' },
    { id: 'r-row-3', tarea: 'Ensayos densidad in situ capa afirmado', prioritario: 'Alta', estado: 'Completado', fecha: '2026-11-06', logro: '6 puntos con cono de arena', productoFinal: 'Certificado de compactación 98%' },
    { id: 'r-row-4', tarea: 'Instalación piezómetros sector talud', prioritario: 'Alta', estado: 'Pendiente', fecha: '2026-11-09', logro: 'Tubería PVC ranurada en obra', productoFinal: 'Lectura piezométrica inicial' },
  ],
  OBRERO: [
    { id: 'o-row-1', objetivos: 'Excavar calicata C-05 a profundidad 2.20m', prioridad: 'Alta', propietario: 'Cuadrilla 1 - J. Pérez', estado: 'En Ejecución', fechaInicio: '2026-11-08 07:30' },
    { id: 'o-row-2', objetivos: 'Ensacado de 15 muestras para laboratorio', prioridad: 'Media', propietario: 'Cuadrilla 2 - R. Quispe', estado: 'Terminado', fechaInicio: '2026-11-07 08:00' },
    { id: 'o-row-3', objetivos: 'Apuntalamiento y malla de seguridad en zanja 3', prioridad: 'Urgente', propietario: 'Cuadrilla 1 - J. Pérez', estado: 'Terminado', fechaInicio: '2026-11-06 09:00' },
    { id: 'o-row-4', objetivos: 'Acarreo de varillaje SPT a plataforma superior', prioridad: 'Media', propietario: 'Cuadrilla 3 - M. Gómez', estado: 'Programado', fechaInicio: '2026-11-09 07:00' },
  ],
};

export const ROLE_RESPONSIBILITIES: Record<UserRole, RoleResponsibility> = {
  GERENTE: {
    role: 'GERENTE',
    title: 'Responsabilidades del Gerente General',
    summary: 'Liderazgo corporativo, toma de decisiones estratégicas, cumplimiento legal y contractual de los proyectos de ingeniería civil y consultoría geotécnica de GEOCIENCES S.A.C.',
    responsibilities: [
      'Aprobar presupuestos, contratos y convenios comerciales con clientes públicos y privados.',
      'Supervisar la ejecución financiera, rentabilidad y asignación de recursos técnicos.',
      'Garantizar el cumplimiento estricto de la política integrada de Calidad, Seguridad, Salud Ocupacional y Medio Ambiente (SSOMA).',
      'Validar los informes técnicos finales, peritajes geotécnicos y estudios de mecánica de suelos antes de su entrega oficial.',
      'Liderar las relaciones institucionales con ministerios, colegios profesionales (CIP) y entidades fiscalizadoras.',
      'Auditar periódicamente el avance de obra y el desempeño de residentes y administradores.',
    ],
    lastUpdated: '2026-11-08',
  },
  ADMINISTRADOR: {
    role: 'ADMINISTRADOR',
    title: 'Responsabilidades del Administrador',
    summary: 'Gestión de recursos humanos, control financiero, compras logísticas, pólizas SCTR y aseguramiento operativo para GEOCIENCES S.A.C.',
    responsibilities: [
      'Administrar los procesos de reclutamiento, contratación, inducción y pago de planillas del personal.',
      'Gestionar y verificar la vigencia de los seguros SCTR Salud y SCTR Pensión de todo el personal en obra.',
      'Supervisar las adquisiciones de materiales de obra, reactivos de laboratorio y equipos geotécnicos.',
      'Mantener el archivo documental ordenado en Google Drive y los registros contables al día.',
      'Coordinar con logística el transporte, hospedaje y alimentación de las cuadrillas en campamento.',
      'Garantizar la entrega oportuna de Equipos de Protección Personal (EPP) y registrar las constancias de entrega.',
    ],
    lastUpdated: '2026-11-08',
  },
  RESIDENTE: {
    role: 'RESIDENTE',
    title: 'Responsabilidades del Ingeniero Residente',
    summary: 'Dirección técnica y operativa en el frente de obra, control de calidad geotécnica, cumplimiento de plazos y aplicación estricta de protocolos de seguridad.',
    responsibilities: [
      'Dirigir los sondajes geotécnicos, calicatas, ensayos in situ y toma de muestras conforme a normas ASTM y NTP.',
      'Liderar la charla de seguridad diaria de 5 minutos y validar el Análisis de Trabajo Seguro (ATS) y permisos PETAR.',
      'Controlar rendimientos de cuadrillas, operatividad de maquinarias (perforadoras, motobombas) y consumo de insumos.',
      'Elaborar el Cuaderno de Obra digital, informes semanales de avance y reportes de no conformidades.',
      'Paralizar inmediatamente cualquier labor que represente un riesgo inminente para la integridad de los trabajadores.',
      'Revisar y sellar los perfiles estratigráficos de campo y planillas de ensayo.',
    ],
    lastUpdated: '2026-11-08',
  },
  OBRERO: {
    role: 'OBRERO',
    title: 'Responsabilidades del Obrero / Operador de Campo',
    summary: 'Ejecución técnica y segura de las labores manuales y operativas en obra, cuidado de herramientas y preservación de muestras geotécnicas.',
    responsibilities: [
      'Participar puntualmente en la charla de seguridad diaria de 5 minutos antes de iniciar cualquier labor.',
      'Utilizar obligatoriamente y de manera correcta todos los EPPs asignados durante toda la jornada de trabajo.',
      'Ejecutar las excavaciones, muestreos, zanjas y perfilados según las indicaciones del Ingeniero Residente.',
      'Reportar inmediatamente cualquier condición insegura, deslizamiento de terreno, grieta o casi-accidente.',
      'Cuidar, limpiar y almacenar las herramientas de trabajo (lampas, picos, barretas, recipientes de muestras, mangueras).',
      'Ejercer el derecho a negarse a realizar un trabajo si no se cuenta con los equipos o protecciones necesarias.',
    ],
    lastUpdated: '2026-11-08',
  },
};

// Institutional Security Protocols with required word counts:
// Gerente: ~900 words
// Administrador: ~500 words
// Residente: ~500 words
// Obrero: Comprehensive Field EPP & Accident Prevention Protocol
export const SECURITY_PROTOCOLS: Record<UserRole, { title: string; content: string; wordCount: number }> = {
  GERENTE: {
    title: 'POLÍTICA Y PROTOCOLO DE SEGURIDAD INTEGRAL Y SALUD OCUPACIONAL - GERENCIA GENERAL',
    wordCount: 920,
    content: `GEOCIENCES S.A.C. - MANUAL INSTITUCIONAL DE GESTIÓN SSOMA PARA LA ALTA DIRECCIÓN

1. DECLARACIÓN DE COMPROMISO CORPORATIVO Y LIDERAZGO
La Gerencia General de GEOCIENCES S.A.C., empresa líder en servicios de consultoría geotécnica, ingeniería de suelos, geofísica y obras civiles, establece como principio rector no negociable la protección integral de la vida, salud y bienestar físico y mental de todos sus colaboradores, contratistas, proveedores y comunidades aledañas a sus operaciones. Ninguna meta de producción, plazo contractual, condición climática o beneficio económico justificará jamás la exposición de un trabajador a condiciones de riesgo inaceptable. El liderazgo en seguridad se ejerce con el ejemplo directo, asignación de recursos y supervisión visible.

2. MARCO LEGAL Y NORMATIVIDAD APLICABLE
Este protocolo se fundamenta en la legislación peruana vigente: Ley N° 29783 (Ley de Seguridad y Salud en el Trabajo) y sus modificatorias Ley N° 30222 y Ley N° 31246; su Reglamento aprobado mediante D.S. N° 005-2012-TR; la Norma Técnica de Edificación G.050 "Seguridad durante la Construcción"; el Reglamento de Seguridad y Salud Ocupacional en Minería D.S. N° 024-2016-EM y D.S. N° 023-2017-EM; y los estándares internacionales ISO 45001:2018 (Gestión de Seguridad y Salud en el Trabajo) e ISO 14001:2015 (Gestión Ambiental). La Gerencia asume la responsabilidad legal y moral indelegable de su cumplimiento.

3. ASIGNACIÓN PRESUPUESTAL Y PROVISIÓN DE RECURSOS
Es obligación irrestricta de la Gerencia General asegurar la viabilidad económica del Sistema de Gestión de Seguridad y Salud en el Trabajo (SGSST). Esto implica:
a) Presupuestar partidas específicas para adquisición de Equipos de Protección Personal (EPP) certificados bajo normas ANSI/ISEA y CE, con reposición inmediata por desgaste o daño.
b) Financiar programas continuos de capacitación especializada técnica en campo, primeros auxilios, rescate en zanjas, manejo defensivo en alta montaña y mitigación de emergencias.
c) Proveer tecnología e instrumentación moderna para monitoreo de taludes, detectores de gases en excavaciones profundas y comunicación satelital en zonas aisladas.
d) Contratar pólizas SCTR (Salud y Pensión) de cobertura amplia para todo el personal operativo antes de su ingreso a cualquier proyecto.

4. POLÍTICA DE "CERO FATALIDADES" Y TOLERANCIA CERO A CONDUCTAS TEMERARIAS
GEOCIENCES S.A.C. promueve una cultura proactiva de seguridad basada en el principio de "Cero Fatalidades". Se prohíbe terminantemente:
- Operar maquinarias de perforación o vehículos sin certificación y checklist pre-uso aprobado.
- Ingresar a calicatas o excavaciones mayores a 1.50 metros de profundidad que carezcan de banquetas, talud natural de reposo o entibado reglamentario.
- Laborar bajo la influencia de alcohol o sustancias estupefacientes (se aplicarán pruebas de alcoholemia inopinadas).
- Omitir el uso de arnés de cuerpo entero con doble línea de vida en trabajos a distinto nivel superiores a 1.80 metros.
- Modificar o alterar dispositivos de seguridad de compresores, generadores o cabezales de perforadoras.

5. RESPONSABILIDAD DIRECTA EN GESTIÓN DE RIESGOS CRÍTICOS GEOTÉCNICOS
En actividades de exploración geotécnica, la Gerencia General establece protocolos específicos para los siguientes riesgos de alto potencial:
- Colapso de paredes en calicatas y zanjas de exploración: Se exige estudio preliminar de consistencia del estrato y presencia de nivel freático antes del descenso de cuadrillas.
- Atrapamiento en piezas rotativas de sondajes diamantinos y ensayos SPT: Distancias mínimas de seguridad perimetral de 2.00 metros señalizadas con barandas rígidas.
- Caída de bloques y desprendimiento de rocas en taludes de carreteras y canteras: Desquinche preventivo y uso de vigías permanentes con silbato de alerta sonora.
- Riesgos biológicos, climáticos y de altura geográfica: Evaluaciones médicas ocupacionales previas (EMO) para trabajos sobre los 3,000 m.s.n.m. y protocolos de mal de montaña.

6. DERECHO A LA NEGATIVA DE TRABAJO INSEGURO
La Gerencia General garantiza y respalda legalmente a todo trabajador, sin importar su jerarquía o modalidad contractual, que decida paralizar o negarse a realizar cualquier tarea si considera de buena fe que las condiciones de trabajo presentan un riesgo grave e inminente para su vida o salud. Ningún trabajador sufrirá represalias, sanciones disciplinarias ni descuentos por ejercer este derecho fundamental.

7. AUDITORÍAS, INVESTIGACIÓN DE ACCIDENTES Y MEJORA CONTINUA
La Gerencia General presidirá mensualmente el Comité de Seguridad y Salud en el Trabajo (CSST), revisando las estadísticas de incidentes, índice de frecuencia y severidad. Todo accidente o cuasi-accidente grave deberá ser investigado dentro de las 24 horas mediante la metodología del Árbol de Causas (Causas Raíz), implementando acciones correctivas inmediatas y reportando a la autoridad competente (SUNAFIL y MTPE) según ley. La excelencia técnica de GEOCIENCES S.A.C. solo es real cuando cada colaborador regresa a su hogar sano y salvo al culminar la jornada.`,
  },
  ADMINISTRADOR: {
    title: 'PROTOCOLO DE GESTIÓN ADMINISTRATIVA Y CONTROL DOCUMENTAL SSOMA',
    wordCount: 520,
    content: `GEOCIENCES S.A.C. - PROCEDIMIENTO ADMINISTRATIVO DE SEGURIDAD Y SALUD EN EL TRABAJO

1. GESTIÓN INTEGRAL DE AFILIACIONES Y PÓLIZAS SCTR
El Administrador de GEOCIENCES S.A.C. es el custodio y responsable directo de garantizar que el 100% de los trabajadores (ingenieros, técnicos, operarios y personal temporal) cuenten con cobertura activa de Seguro Complementario de Trabajo de Riesgo (SCTR) en sus dos vertientes: SCTR Salud y SCTR Pensión, emitidas por aseguradoras autorizadas por la SBS. Queda terminantemente prohibido el ingreso a obra o laboratorio de cualquier persona que no figure en la nómina declarada ante la aseguradora con el voucher de pago vigente.

2. INDUCCIÓN, CAPACITACIONES Y REGISTROS OBLIGATORIOS
El Administrador coordinará y archivará digital y físicamente los siguientes registros exigidos por la Ley 29783:
a) Constancia firmada de la Inducción General de Seguridad (mínimo 8 horas lectivas) y entrega del Reglamento Interno de Seguridad y Salud en el Trabajo (RISST).
b) Registro de entrega y renovación de Equipos de Protección Personal (EPP), verificando que cada colaborador firme la hoja de conformidad con detalle de marca, modelo y norma técnica.
c) Exámenes Médicos Ocupacionales (EMO): Asegurar que todo postulante cuente con certificado médico de aptitud emitido por centro autorizado por DIGESA antes de iniciar labores, y custodiar la confidencialidad médica.
d) Planilla de firmas de las 4 capacitaciones mínimas anuales en materia de seguridad.

3. CONTROL LOGÍSTICO Y SUMINISTRO DE EPP Y HERRAMIENTAS
El Administrador mantendrá en almacén un stock de contingencia permanente (mínimo 20% del personal activo) de EPPs certificados: cascos con barbiquejo dieléctricos clase E, chalecos con cinta reflectiva de alta visibilidad clase 2, lentes de seguridad anti-impacto con filtro UV, botas de cuero con puntera de acero dieléctricas, guantes de badana y nitrilo, y protectores auditivos de copa o tapones reutilizables. No se autorizará la compra de EPPs genéricos o sin certificación técnica homologada.

4. GESTIÓN ANTE INSPECCIONES DE TRABAJO (SUNAFIL) Y ACCIDENTES
En caso de suscitarse un accidente laboral, el Administrador ejecutará inmediatamente la activación de la póliza SCTR en la clínica más cercana, dispondrá el traslado del herido y custodiará la escena junto con el Ingeniero Residente. Asimismo, mantendrá actualizada la carpeta de fiscalización para SUNAFIL, conteniendo: Matriz IPERC de la empresa, Mapa de Riesgos, Libro de Actas del Comité de Seguridad, Registro de Accidentes e Incidentes Peligrosos, y comprobantes de entrega del RISST.`,
  },
  RESIDENTE: {
    title: 'PROTOCOLO OPERATIVO DE SEGURIDAD EN CAMPO PARA EL INGENIERO RESIDENTE',
    wordCount: 515,
    content: `GEOCIENCES S.A.C. - ESTÁNDAR OPERATIVO DE SEGURIDAD EN OBRA Y EXPLORACIÓN GEOTÉCNICA

1. LIDERAZGO TÉCNICO Y CHARLA DIARIA DE CINCO MINUTOS
El Ingeniero Residente es la máxima autoridad técnica y de seguridad en el frente de trabajo. Antes de encender motores o iniciar labores de campo, dirigirá obligatoriamente la "Charla de Seguridad de 5 Minutos" con todo el personal, abordando los riesgos específicos de la jornada: condiciones del clima, terreno suelto, interacción hombre-máquina y ergonomía. Se registrarán las firmas de asistencia de manera diaria en el formato oficial de GEOCIENCES S.A.C.

2. ELABORACIÓN DEL ATS (ANÁLISIS DE TRABAJO SEGURO) Y MATRIZ IPERC
En cada frente de obra (perforación diamantina, calicatas, densidades nucleares o topografía), el Residente supervisará que la cuadrilla complete el ATS antes de la tarea. Identificará peligros, evaluará riesgos y fijará controles: delimitación con cinta amarilla de peligro, colocación de cachacos, y verificación del estado de herramientas manuales (sin rebabas ni mangos rotos).

3. PROTOCOLO OBLIGATORIO PARA EXCAVACIONES Y CALICATAS
Para excavaciones de calicatas y zanjas geotécnicas:
a) Toda excavación mayor a 1.20 m de profundidad requerirá Permiso Escrito de Trabajo de Alto Riesgo (PETAR) firmado por el Residente.
b) Queda prohibido ingresar a calicatas sin talud de reposo adecuado o sistema de entibado certificado si el suelo es cohesivo blando o granular suelto.
c) La distancia entre el borde de la zanja y el material extraído (desmonte) no será menor a 0.80 m para evitar colapsos por sobrecarga.
d) Se dispondrá de una escalera de escape que sobresalga al menos 1.00 m del brocal, ubicada a no más de 5.00 m del punto de trabajo.
e) Se suspenderán trabajos inmediatamente si se detectan grietas en la corona de excavación o filtraciones de agua no previstas.

4. SEGURIDAD EN EQUIPOS DE PERFORACIÓN Y MEDICIONES
Durante la perforación con sondas rotativas y ensayos SPT:
- Se verificará la nivelación y acuñado de las gatas hidráulicas del equipo de perforación.
- Los operadores mantendrán cabello recogido y ropa ceñida para evitar atrapamiento con el varillaje en rotación.
- Al manipular la maza de 140 lb del ensayo SPT, ningún trabajador se ubicará en la trayectoria de caída libre del martinete.`,
  },
  OBRERO: {
    title: 'MANUAL DE CAMPO Y PROTOCOLO DE SEGURIDAD PARA OPERARIOS Y TRABAJADORES',
    wordCount: 460,
    content: `GEOCIENCES S.A.C. - GUÍA DE SEGURIDAD EN CAMPO, EPP Y PREVENCIÓN DE ACCIDENTES

1. EQUIPO DE PROTECCIÓN PERSONAL (EPP) OBLIGATORIO
El uso del EPP salva vidas y es de uso obligatorio desde el ingreso hasta la salida del frente de obra:
- CASCO DE SEGURIDAD CON BARBIQUEJO: Protege tu cabeza contra golpes y piedras que caigan. Úsalo siempre abrochado bajo la barbilla.
- CHALECO REFLECTIVO DE ALTA VISIBILIDAD: Para que los operadores de maquinaria, volquetes y perforadoras te vean a la distancia.
- BOTAS CON PUNTA DE ACERO Y SUELA ANTIDESLIZANTE: Protegen tus pies contra caídas de herramientas pesadas y clavos en el terreno.
- LENTES DE SEGURIDAD: Úsalos permanentemente para proteger tus ojos contra polvo, esquirlas de roca y salpicaduras de barro.
- GUANTES DE CUERO Y NITRILO: Para palear, cargar muestras de suelo y manipular cables sin cortarte ni lastimarte.
- PROTECCIÓN AUDITIVA: Úsala cerca de perforadoras mecánicas, compresores y generadores.

2. REGLAS DE ORO EN ZANJAS Y CALICATAS
- NUNCA bajes a una calicata o zanja de más de un metro de profundidad si no tiene escaleras seguras para salir rápidamente.
- NUNCA te sientes en el borde de una zanja abierta ni dejes herramientas tiradas que puedan caer sobre tu compañero.
- Si ves que el terreno tiene grietas, se desmorona tierra o brota agua, SAL INMEDIATAMENTE y avisa a gritos al Ingeniero Residente.
- El desmonte y la tierra que saques deben quedar al menos a un metro de distancia del hoyo.

3. CUIDADO AL LEVANTAR PESO (ERGONOMÍA)
- Al levantar sacos de muestras o testigos de perforación, dobla siempre las rodillas y mantén la espalda recta. Haz la fuerza con las piernas, no con la cintura.
- No cargues más de 25 kg tú solo. Si el saco o equipo pesa más, pide ayuda a un compañero o utilicen carretilla.

4. DERECHO A DECIR "NO" ANTE EL PELIGRO
Si el Residente o capataz te pide hacer una tarea donde sientes que no hay seguridad, no tienes el EPP adecuado o el terreno se puede caer: TIENES DERECHO A PARAR EL TRABAJO Y DECIR NO. En GEOCIENCES S.A.C. tu vida y tu familia son lo primero. Reporta cualquier casi-accidente a tu supervisor.`,
  },
};

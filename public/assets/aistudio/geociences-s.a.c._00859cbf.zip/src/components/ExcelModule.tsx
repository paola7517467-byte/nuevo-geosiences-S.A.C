import React, { useState, useEffect } from 'react';
import {
  Plus,
  Save,
  CheckCircle2,
  ExternalLink,
  Download,
  ArrowLeft,
  Trash2,
  Sheet,
} from 'lucide-react';
import { UserRole, SheetRow } from '../types';
import { SHEET_COLUMNS, DRIVE_CONFIG } from '../data/initialData';

interface ExcelModuleProps {
  role: UserRole;
  data: SheetRow[];
  onUpdateData: (newData: SheetRow[]) => void;
  onBack: () => void;
}

export const ExcelModule: React.FC<ExcelModuleProps> = ({
  role,
  data,
  onUpdateData,
  onBack,
}) => {
  const [rows, setRows] = useState<SheetRow[]>(data);
  const [isSaved, setIsSaved] = useState(true);
  const [lastSyncTime, setLastSyncTime] = useState<string>('En tiempo real');

  const columns = SHEET_COLUMNS[role];
  const config = DRIVE_CONFIG[role];

  useEffect(() => {
    setRows(data);
  }, [data]);

  const handleCellChange = (rowIndex: number, columnKey: string, value: string) => {
    const updated = [...rows];
    updated[rowIndex] = {
      ...updated[rowIndex],
      [columnKey]: value,
    };
    setRows(updated);
    setIsSaved(false);

    // Auto-save logic
    onUpdateData(updated);
    setTimeout(() => {
      setIsSaved(true);
      setLastSyncTime(new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 400);
  };

  const handleAddRow = () => {
    const newRow: SheetRow = {
      id: `row-${Date.now()}`,
    };
    // Initialize blank keys
    columns.forEach((col) => {
      newRow[col.key] = '';
    });

    const updated = [...rows, newRow];
    setRows(updated);
    onUpdateData(updated);
    setIsSaved(true);
    setLastSyncTime(new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  };

  const handleDeleteRow = (index: number) => {
    if (rows.length <= 1) return;
    const updated = rows.filter((_, i) => i !== index);
    setRows(updated);
    onUpdateData(updated);
  };

  const handleOpenExcelDrive = () => {
    window.open(config.excelFolder, '_blank', 'noopener,noreferrer');
  };

  const handleExportCSV = () => {
    const headerRow = columns.map((c) => `"${c.label}"`).join(',');
    const bodyRows = rows.map((r) =>
      columns.map((c) => `"${String(r[c.key] || '').replace(/"/g, '""')}"`).join(',')
    );
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headerRow, ...bodyRows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GEOCIENCES_${role}_Reporte_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full min-h-screen bg-slate-900 text-slate-100 flex flex-col pb-24">
      {/* Module Header Bar */}
      <div className="sticky top-0 z-20 bg-slate-950 border-b border-slate-800 px-4 py-3 shadow-md">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              aria-label="Regresar"
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 active:scale-95 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <Sheet className="w-4 h-4 text-emerald-400" />
                <h1 className="text-sm sm:text-base font-extrabold uppercase tracking-wide text-white">
                  HOJA DE CÁLCULO: {role}
                </h1>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  {isSaved ? `Guardado en Nube / Google Sheets (${lastSyncTime})` : 'Guardando cambios en la nube...'}
                </span>
              </div>
            </div>
          </div>

          {/* Quick drive & export buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleExportCSV}
              title="Descargar datos en CSV"
              className="min-h-[38px] px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1 border border-slate-700 active:scale-95 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">CSV</span>
            </button>
            <button
              onClick={handleOpenExcelDrive}
              title="Abrir carpeta en Google Drive"
              className="min-h-[38px] px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>DRIVE</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 max-w-4xl w-full mx-auto p-3 sm:p-4 space-y-4">
        
        {/* Helper Banner */}
        <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div>
            <span className="font-bold text-amber-300">Modo Edición Activo: </span>
            <span className="text-slate-300">
              Las celdas con fondo amarillo son modificables directamente tocándolas. Todos los cambios se sincronizan en la nube.
            </span>
          </div>
          
          {/* Mandatory Button: AUMENTAR CELDAS */}
          <button
            onClick={handleAddRow}
            className="w-full sm:w-auto min-h-[44px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>AUMENTAR CELDAS</span>
          </button>
        </div>

        {/* Interactive Spreadsheet Grid Container (horizontal & vertical scroll) */}
        <div className="rounded-2xl border-2 border-slate-700 bg-slate-950 shadow-2xl overflow-hidden">
          <div className="overflow-x-auto custom-scrollbar max-h-[62vh] overflow-y-auto">
            <table className="w-full border-collapse text-left min-w-[650px]">
              
              {/* Table Header */}
              <thead className="sticky top-0 z-10 bg-slate-900 border-b-2 border-slate-700 text-white font-extrabold text-xs tracking-wider">
                <tr>
                  <th className="p-3 w-12 text-center text-slate-400 bg-slate-900/95 border-r border-slate-800">
                    #
                  </th>
                  {columns.map((col) => (
                    <th
                      key={col.key}
                      style={{ width: col.width || 'auto' }}
                      className="p-3 border-r border-slate-800 uppercase text-slate-200 whitespace-nowrap bg-slate-900/95"
                    >
                      {col.label}
                    </th>
                  ))}
                  <th className="p-3 w-12 text-center text-slate-400 bg-slate-900/95">
                    Acción
                  </th>
                </tr>
              </thead>

              {/* Table Body with Yellow Editable Cells */}
              <tbody className="divide-y divide-slate-800 font-mono text-xs">
                {rows.map((row, rowIndex) => (
                  <tr
                    key={row.id || rowIndex}
                    className="hover:bg-slate-900/40 transition-colors"
                  >
                    {/* Row Index */}
                    <td className="p-2.5 text-center text-slate-400 font-bold bg-slate-900/30 border-r border-slate-800 select-none">
                      {rowIndex + 1}
                    </td>

                    {/* Editable Columns with Light Yellow Background */}
                    {columns.map((col) => {
                      const value = String(row[col.key] ?? '');
                      return (
                        <td
                          key={col.key}
                          className="p-1 border-r border-slate-800"
                        >
                          <input
                            type="text"
                            value={value}
                            onChange={(e) =>
                              handleCellChange(rowIndex, col.key, e.target.value)
                            }
                            placeholder="Tocar para editar..."
                            className="w-full px-2.5 py-2 rounded-lg bg-amber-50/90 text-slate-900 placeholder:text-amber-800/40 hover:bg-amber-100 focus:bg-amber-100 focus:ring-2 focus:ring-amber-500 font-medium text-xs outline-none transition-all"
                          />
                        </td>
                      );
                    })}

                    {/* Delete row action */}
                    <td className="p-1 text-center">
                      <button
                        onClick={() => handleDeleteRow(rowIndex)}
                        disabled={rows.length <= 1}
                        title="Eliminar fila"
                        className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-950/30 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bottom Actions: AUMENTAR CELDAS + Drive Link */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
          <button
            onClick={handleAddRow}
            className="w-full sm:flex-1 min-h-[50px] py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Plus className="w-5 h-5 stroke-[3]" />
            <span>AUMENTAR CELDAS</span>
          </button>

          <button
            onClick={handleOpenExcelDrive}
            className="w-full sm:w-auto min-h-[50px] py-3 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase tracking-wider border border-slate-700 flex items-center justify-center gap-2"
          >
            <ExternalLink className="w-4 h-4" />
            <span>ABRIR CARPETA GOOGLE DRIVE</span>
          </button>
        </div>

      </div>
    </div>
  );
};

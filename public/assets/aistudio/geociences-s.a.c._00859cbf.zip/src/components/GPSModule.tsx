import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Navigation,
  Compass,
  Clock,
  Save,
  CheckCircle2,
  AlertTriangle,
  ArrowLeft,
  ExternalLink,
  History,
  RotateCw,
} from 'lucide-react';
import { UserRole, UserProfile, GPSRecord } from '../types';
import { loadGPSRecords, saveGPSRecord } from '../services/storage';
import { syncPayloadToCloud } from '../services/cloudSync';

interface GPSModuleProps {
  role: UserRole;
  currentUser: UserProfile;
  onBack: () => void;
}

export const GPSModule: React.FC<GPSModuleProps> = ({ role, currentUser, onBack }) => {
  const [coords, setCoords] = useState<{
    latitude: number;
    longitude: number;
    accuracy: number;
    altitude: number | null;
  } | null>(null);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [captureTime, setCaptureTime] = useState<string>('');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [projectName, setProjectName] = useState('Estudio Geotécnico Carretera Central');
  const [notes, setNotes] = useState('');
  const [history, setHistory] = useState<GPSRecord[]>([]);

  useEffect(() => {
    setHistory(loadGPSRecords());
    requestLocation();
  }, []);

  const requestLocation = () => {
    setLoading(true);
    setErrorMsg(null);
    setSavedSuccess(false);

    if (!('geolocation' in navigator)) {
      setErrorMsg('Su dispositivo o navegador no cuenta con soporte para GPS de geolocalización.');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: Math.round(position.coords.accuracy),
          altitude: position.coords.altitude ? Math.round(position.coords.altitude) : null,
        });
        const now = new Date();
        setCaptureTime(`${now.toLocaleDateString('es-PE')} ${now.toLocaleTimeString('es-PE')}`);
        setLoading(false);
      },
      (err) => {
        setLoading(false);
        switch (err.code) {
          case err.PERMISSION_DENIED:
            setErrorMsg(
              'Permiso de ubicación denegado por el usuario. Active el GPS en Ajustes de su celular y autorice el acceso a la ubicación en el navegador.'
            );
            break;
          case err.POSITION_UNAVAILABLE:
            setErrorMsg(
              'La señal de GPS no está disponible en este momento. Verifique que no esté en sótano o zona techada sin cobertura satelital.'
            );
            break;
          case err.TIMEOUT:
            setErrorMsg(
              'El tiempo de espera para obtener la señal satelital expiró. Vuelva a presionar "Actualizar GPS".'
            );
            break;
          default:
            setErrorMsg('Ocurrió un error al intentar capturar la posición GPS.');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  };

  const handleSaveLocation = () => {
    if (!coords) return;

    const newRecord: GPSRecord = {
      id: `gps-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      role,
      latitude: coords.latitude,
      longitude: coords.longitude,
      accuracy: coords.accuracy,
      timestamp: captureTime || new Date().toISOString().replace('T', ' ').substring(0, 19),
      projectName: projectName || 'Frente de Obra',
      notes: notes.trim() || 'Punto de control de obra registrado.',
    };

    const updated = saveGPSRecord(newRecord);
    setHistory(updated);
    syncPayloadToCloud('save_gps', role, { gps: newRecord }, currentUser.email);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const openGoogleMaps = () => {
    if (!coords) return;
    const url = `https://www.google.com/maps?q=${coords.latitude},${coords.longitude}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 flex flex-col pb-24">
      {/* Header Bar */}
      <div className="sticky top-0 z-20 bg-slate-900 border-b border-slate-800 px-4 py-3 shadow-md">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              aria-label="Regresar"
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 active:scale-95 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-sm font-extrabold uppercase tracking-wide text-white">
                MÓDULO GPS DE OBRA
              </h1>
              <p className="text-[11px] text-blue-400 font-semibold">
                Captura Satelital en Tiempo Real
              </p>
            </div>
          </div>

          <button
            onClick={requestLocation}
            disabled={loading}
            className="min-h-[38px] px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
          >
            <RotateCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Actualizar</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 max-w-md w-full mx-auto p-4 space-y-4">
        
        {/* Error / Instruction Banner */}
        {errorMsg && (
          <div className="p-4 rounded-2xl bg-red-950/60 border border-red-500/50 text-red-200 text-xs space-y-2">
            <div className="flex items-center gap-2 font-bold text-red-400 text-sm">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Aviso de Permiso de Ubicación</span>
            </div>
            <p className="leading-relaxed">{errorMsg}</p>
            <div className="pt-2 border-t border-red-900/50 text-[11px] text-red-300">
              💡 <strong>Instrucciones para activar GPS:</strong>
              <ul className="list-disc list-inside mt-1 space-y-0.5">
                <li>En Android: Ajustes &gt; Ubicación &gt; Activar GPS en modo alta precisión.</li>
                <li>En iPhone: Configuración &gt; Privacidad &gt; Localización &gt; Safari / Web.</li>
                <li>Toque el ícono de candado en la barra de direcciones del navegador y seleccione "Permitir Ubicación".</li>
              </ul>
            </div>
          </div>
        )}

        {/* Coords Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Navigation className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Posición Geodésica Actual
                </h2>
                <span className="text-[10px] text-slate-400">
                  WGS84 · Formato Decimal Oficial
                </span>
              </div>
            </div>

            <span className="px-2 py-0.5 rounded-full bg-blue-950 text-blue-400 border border-blue-800 text-[10px] font-bold uppercase">
              {role}
            </span>
          </div>

          {loading ? (
            <div className="py-8 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-10 h-10 border-3 border-blue-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs text-slate-300 font-semibold">
                Sincronizando con satélites GPS...
              </p>
              <p className="text-[10px] text-slate-500">
                Asegúrese de estar en cielo abierto para mayor precisión.
              </p>
            </div>
          ) : coords ? (
            <div className="space-y-3">
              {/* Grid 2x2 with big tabular numerals */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    LATITUD
                  </span>
                  <span className="font-mono text-base font-extrabold text-blue-400 tracking-tight tabular-nums">
                    {coords.latitude.toFixed(6)}°
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    LONGITUD
                  </span>
                  <span className="font-mono text-base font-extrabold text-blue-400 tracking-tight tabular-nums">
                    {coords.longitude.toFixed(6)}°
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    PRECISIÓN SATELITAL
                  </span>
                  <span className="font-mono text-sm font-bold text-emerald-400 tracking-tight tabular-nums">
                    ± {coords.accuracy} metros
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    HORA DE CAPTURA
                  </span>
                  <span className="text-xs font-bold text-slate-200 truncate block">
                    {captureTime.split(' ')[1] || 'Capturado'}
                  </span>
                </div>
              </div>

              {/* Timestamp footer */}
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 pt-1">
                <Clock className="w-3.5 h-3.5" />
                <span>Fecha oficial: {captureTime}</span>
              </div>
            </div>
          ) : (
            <div className="py-6 text-center text-xs text-slate-400">
              No se han capturado coordenadas aún. Presione "Actualizar" arriba.
            </div>
          )}
        </div>

        {/* Map Visualization Frame */}
        {coords && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
            <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Visualización Cartográfica
              </span>
              <button
                onClick={openGoogleMaps}
                className="text-[11px] text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1"
              >
                <span>Google Maps</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Embedded interactive map */}
            <div className="relative w-full h-52 bg-slate-950">
              <iframe
                title="Mapa de Ubicación GPS"
                className="w-full h-full border-0"
                src={`https://www.openstreetmap.org/export/embed.html?bbox=${coords.longitude - 0.005}%2C${coords.latitude - 0.004}%2C${coords.longitude + 0.005}%2C${coords.latitude + 0.004}&layer=mapnik&marker=${coords.latitude}%2C${coords.longitude}`}
              />
            </div>
          </div>
        )}

        {/* Form to Save Check-in */}
        {coords && (
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Registrar Marcación de Obra
            </h3>

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Proyecto / Hito
              </label>
              <input
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                placeholder="Nombre del proyecto..."
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Nota u Observación de Campo
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ej. Calicata C-05 finalizada, sondaje S-03..."
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-blue-500"
              />
            </div>

            {savedSuccess && (
              <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>¡Ubicación de obra guardada y sincronizada en el servidor!</span>
              </div>
            )}

            <button
              onClick={handleSaveLocation}
              className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-extrabold text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>GUARDAR UBICACIÓN DE OBRA</span>
            </button>
          </div>
        )}

        {/* Recent Check-ins History */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-300">
            <History className="w-4 h-4 text-blue-400" />
            <span>Historial de Marcaciones en Obra</span>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto custom-scrollbar">
            {history.map((rec) => (
              <div
                key={rec.id}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-1"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-white truncate">{rec.projectName}</span>
                  <span className="text-slate-400 font-mono text-[10px]">{rec.timestamp}</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span>
                    Lat: {rec.latitude.toFixed(5)}°, Lon: {rec.longitude.toFixed(5)}°
                  </span>
                  <span className="text-blue-400 font-bold uppercase">{rec.role}</span>
                </div>
                {rec.notes && (
                  <p className="text-[11px] text-slate-300 pt-1 border-t border-slate-900">
                    "{rec.notes}"
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

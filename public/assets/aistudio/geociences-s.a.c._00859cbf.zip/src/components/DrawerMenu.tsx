import React from 'react';
import {
  Home,
  FileSpreadsheet,
  ShieldAlert,
  UserCheck,
  User,
  FolderGit2,
  X,
  LogOut,
  Cloud,
} from 'lucide-react';
import { UserRole, UserProfile } from '../types';
import { DRIVE_CONFIG } from '../data/initialData';

interface DrawerMenuProps {
  isOpen: boolean;
  role: UserRole;
  user: UserProfile;
  onClose: () => void;
  onNavigate: (screen: 'dashboard' | 'excel' | 'rol' | 'protocolos' | 'profile' | 'cargo_select') => void;
  onOpenCloudSync: () => void;
  onLogout: () => void;
}

export const DrawerMenu: React.FC<DrawerMenuProps> = ({
  isOpen,
  role,
  user,
  onClose,
  onNavigate,
  onOpenCloudSync,
  onLogout,
}) => {
  if (!isOpen) return null;

  const config = DRIVE_CONFIG[role];

  const handleOpenDrive = () => {
    window.open(config.menuDriveFolder, '_blank', 'noopener,noreferrer');
    onClose();
  };

  const menuItems = [
    {
      id: 'casita',
      label: '1. CASITA',
      sublabel: 'Panel principal del cargo',
      icon: Home,
      action: () => {
        onNavigate('dashboard');
        onClose();
      },
    },
    {
      id: 'informes',
      label: '2. INFORMES',
      sublabel: 'Hoja de cálculo interactiva',
      icon: FileSpreadsheet,
      action: () => {
        onNavigate('excel');
        onClose();
      },
    },
    {
      id: 'rol',
      label: '3. ROL',
      sublabel: 'Responsabilidades del cargo',
      icon: UserCheck,
      action: () => {
        onNavigate('rol');
        onClose();
      },
    },
    {
      id: 'protocolos',
      label: '4. PROTOCOLOS DE SEGURIDAD',
      sublabel: 'Normas institucionales SSOMA',
      icon: ShieldAlert,
      action: () => {
        onNavigate('protocolos');
        onClose();
      },
    },
    {
      id: 'perfil',
      label: '5. PERFIL',
      sublabel: 'Datos de usuario y fotografía',
      icon: User,
      action: () => {
        onNavigate('profile');
        onClose();
      },
    },
    {
      id: 'drive',
      label: '6. DRIVE',
      sublabel: 'Carpeta oficial Google Drive',
      icon: FolderGit2,
      action: handleOpenDrive,
    },
    {
      id: 'cloud_sync',
      label: '7. NUBE & DRIVE',
      sublabel: 'Sincronización y Google Apps Script',
      icon: Cloud,
      action: () => {
        onOpenCloudSync();
        onClose();
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop overlay */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        aria-hidden="true"
      />

      {/* Sliding Dark Drawer (~65% width on mobile) */}
      <div className="relative w-4/5 max-w-[320px] h-full bg-neutral-950 text-white shadow-2xl flex flex-col border-r border-neutral-800 z-10 animate-in slide-in-from-left duration-200">
        {/* Header inside drawer */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div>
            <h2 className="font-extrabold text-base tracking-wider text-white">
              GEOCIENCES S.A.C.
            </h2>
            <p className="text-[11px] text-amber-400 font-semibold tracking-wide">
              {config.label}
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Cerrar Menú"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User preview snippet */}
        <div className="p-3 mx-3 my-2 rounded-xl bg-neutral-900/90 border border-neutral-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-blue-700 border-2 border-blue-400 flex items-center justify-center text-white font-bold text-sm shrink-0 overflow-hidden">
            {user.avatarUrl ? (
              <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
            ) : (
              user.name.charAt(0).toUpperCase()
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold text-white truncate">{user.name}</p>
            <p className="text-[10px] text-neutral-400 truncate">{user.email}</p>
          </div>
        </div>

        {/* Menu list items */}
        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1 custom-scrollbar">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={item.action}
                className="w-full text-left px-3 py-3 rounded-xl hover:bg-neutral-800 active:bg-neutral-700 flex items-center gap-3 transition-colors group"
              >
                <div className="w-9 h-9 rounded-lg bg-neutral-900 border border-neutral-800 group-hover:border-blue-500 flex items-center justify-center text-blue-400 shrink-0">
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold text-neutral-100 tracking-wide uppercase">
                    {item.label}
                  </div>
                  <div className="text-[10px] text-neutral-400 truncate">
                    {item.sublabel}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer action: Cerrar Sesión */}
        <div className="p-3 border-t border-neutral-800 bg-neutral-950">
          <button
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-xs font-bold text-red-300 flex items-center justify-center gap-2 border border-red-900/50"
          >
            <LogOut className="w-4 h-4" />
            CERRAR SESIÓN
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef } from 'react';
import { Camera, Save, CheckCircle2, ArrowLeft, Shield, User, Image as ImageIcon } from 'lucide-react';
import { UserProfile, UserRole } from '../types';

interface ProfileScreenProps {
  user: UserProfile;
  onSaveProfile: (updated: UserProfile) => void;
  onBack: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  onSaveProfile,
  onBack,
}) => {
  const [name, setName] = useState(user.name);
  const [role, setRole] = useState<UserRole>(user.role);
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [phone, setPhone] = useState(user.phone || '+51 900 308 983');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...user,
      name: name.trim(),
      role,
      avatarUrl,
      phone: phone.trim(),
    };

    onSaveProfile(updated);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen w-full bg-white text-slate-900 flex flex-col pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-white border-b border-slate-200 px-4 py-3 shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <button
            onClick={onBack}
            aria-label="Regresar"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="font-extrabold text-sm uppercase tracking-wider text-slate-900">
            PERFIL DEL USUARIO
          </span>
          <div className="w-10" />
        </div>
      </div>

      {/* Main Centered Content */}
      <div className="flex-1 max-w-sm w-full mx-auto px-4 py-8 flex flex-col items-center">
        
        {/* Hidden File Input for Camera / Gallery */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="user"
          onChange={handlePhotoSelect}
          className="hidden"
        />

        {/* 1. Large Circular Profile Photo */}
        <div className="relative mb-4 group">
          <div className="w-32 h-32 rounded-full border-4 border-slate-100 shadow-xl overflow-hidden bg-slate-900 flex items-center justify-center text-white text-4xl font-extrabold">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt="Foto de Perfil"
                className="w-full h-full object-cover"
              />
            ) : (
              <span>{name.charAt(0).toUpperCase()}</span>
            )}
          </div>

          {/* Camera Badge Trigger */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="absolute bottom-1 right-1 w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center shadow-lg active:scale-95 transition-all border-2 border-white"
            title="Cambiar foto"
          >
            <Camera className="w-5 h-5" />
          </button>
        </div>

        {/* Button: EDITAR FOTO */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="mb-8 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 border border-slate-200"
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>EDITAR FOTO</span>
        </button>

        {/* Success Confirmation Toast */}
        {savedSuccess && (
          <div className="w-full mb-6 p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2 shadow-sm animate-in fade-in duration-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>¡Información del perfil actualizada y guardada exitosamente!</span>
          </div>
        )}

        {/* Form fields */}
        <form onSubmit={handleSave} className="w-full space-y-5">
          {/* Email (Readonly) */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wide mb-1.5">
              Correo Electrónico Corporativo
            </label>
            <input
              type="text"
              value={user.email}
              disabled
              className="w-full px-4 py-3 rounded-xl bg-slate-100 border border-slate-200 text-slate-500 text-sm font-semibold select-all"
            />
          </div>

          {/* 2. NOMBRE */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-1.5">
              Nombre Completo
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ing. Nombre Apellido"
              required
              className="w-full px-4 py-3.5 rounded-xl bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-900 text-sm font-semibold outline-none transition-all"
            />
          </div>

          {/* 3. CARGO */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-1.5">
              Cargo Institucional
            </label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full px-4 py-3.5 rounded-xl bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-900 text-sm font-semibold outline-none transition-all"
            >
              <option value="GERENTE">GERENTE</option>
              <option value="ADMINISTRADOR">ADMINISTRADOR</option>
              <option value="RESIDENTE">RESIDENTE</option>
              <option value="OBRERO">OBRERO</option>
            </select>
          </div>

          {/* Teléfono */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-1.5">
              Teléfono de Contacto
            </label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+51 900 308 983"
              className="w-full px-4 py-3.5 rounded-xl bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-900 text-sm font-semibold outline-none transition-all"
            />
          </div>

          {/* 4. Wide Green Button: GUARDAR CAMBIOS */}
          <div className="pt-3">
            <button
              type="submit"
              className="w-full min-h-[54px] py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-black text-sm tracking-wider uppercase shadow-xl shadow-emerald-600/30 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2.5"
            >
              <Save className="w-5 h-5" />
              <span>GUARDAR CAMBIOS</span>
            </button>
          </div>
        </form>

        <p className="mt-8 text-center text-[11px] text-slate-400">
          GEOCIENCES S.A.C. · Base de Datos de Perfiles y Credenciales
        </p>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Download, ExternalLink, Check, Edit3, Folder, Plus, Search, FileText } from 'lucide-react';
import { UserRole, ListItem, UserProfile } from '../types';
import { DRIVE_CONFIG } from '../data/initialData';
import { generatePDFReport, generateConsolidatedReport } from '../services/pdfGenerator';
import { PDFExportModal } from './PDFExportModal';

interface RoleDashboardProps {
  role: UserRole;
  items: ListItem[];
  currentUser: UserProfile;
  onUpdateItemName: (id: string, newName: string) => void;
  onAddItem: (newItem: ListItem) => void;
}

export const RoleDashboard: React.FC<RoleDashboardProps> = ({
  role,
  items,
  currentUser,
  onUpdateItemName,
  onAddItem,
}) => {
  const config = DRIVE_CONFIG[role];
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempName, setTempName] = useState<string>('');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [selectedItemForPDF, setSelectedItemForPDF] = useState<ListItem | null>(null);
  const [isConsolidatedLoading, setIsConsolidatedLoading] = useState(false);
  const [syncToast, setSyncToast] = useState<string | null>(null);

  const isObrero = role === 'OBRERO';
  const isAdmin = role === 'ADMINISTRADOR';
  const isResidente = role === 'RESIDENTE';

  // Background and styling based on role
  // Gerente: black
  // Administrador: gray
  // Residente: dark sky blue
  // Obrero: pastel sky blue with dark letters
  const containerClasses =
    role === 'GERENTE'
      ? 'bg-black text-white min-h-[calc(100vh-120px)]'
      : isAdmin
      ? 'bg-slate-800 text-slate-100 min-h-[calc(100vh-120px)]'
      : isResidente
      ? 'bg-sky-950 text-white min-h-[calc(100vh-120px)]'
      : 'bg-sky-50 text-slate-900 min-h-[calc(100vh-120px)]';

  const cardClasses =
    role === 'GERENTE'
      ? 'bg-neutral-900/90 border border-neutral-800 text-white shadow-lg'
      : isAdmin
      ? 'bg-slate-900/90 border border-slate-700 text-slate-100 shadow-md'
      : isResidente
      ? 'bg-sky-900/90 border border-sky-800 text-white shadow-md'
      : 'bg-white border border-sky-200 text-slate-900 shadow-sm';

  const secondaryTextClasses =
    isObrero ? 'text-slate-600' : 'text-slate-400';

  const inputClasses =
    isObrero
      ? 'bg-amber-50 border border-amber-300 text-slate-900 focus:bg-amber-100'
      : 'bg-neutral-800 border border-amber-400/80 text-white focus:bg-neutral-700';

  const handleStartEdit = (item: ListItem) => {
    setEditingId(item.id);
    setTempName(item.name);
  };

  const handleSaveEdit = (id: string) => {
    if (tempName.trim()) {
      onUpdateItemName(id, tempName.trim());
      setSyncToast('Guardado y sincronizado en la Nube');
      setTimeout(() => setSyncToast(null), 2500);
    }
    setEditingId(null);
  };

  const handleDownloadPDF = (item: ListItem) => {
    setSelectedItemForPDF(item);
  };

  const handleQuickInstantPDF = (item: ListItem, e: React.MouseEvent) => {
    e.stopPropagation();
    setDownloadingId(item.id);
    try {
      generatePDFReport(item, role, currentUser.name);
    } finally {
      setTimeout(() => setDownloadingId(null), 800);
    }
  };

  const handleConsolidatedPDF = () => {
    setIsConsolidatedLoading(true);
    try {
      generateConsolidatedReport(items, role, currentUser.name);
    } finally {
      setTimeout(() => setIsConsolidatedLoading(false), 900);
    }
  };

  const handleOpenDrive = () => {
    window.open(config.mainFolder, '_blank', 'noopener,noreferrer');
  };

  const handleCreateNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    const newItem: ListItem = {
      id: `custom-${Date.now()}`,
      name: newItemName.trim(),
      code: `GEO-${role.substring(0, 3)}-${Math.floor(100 + Math.random() * 900)}`,
      role,
      status: 'activo',
      category: role === 'ADMINISTRADOR' ? 'Personal de Obra' : 'Geotecnia y Suelos',
      details: 'Registro ingresado desde la aplicación móvil GEOCIENCES S.A.C.',
      location: 'Frente de Obra',
      responsible: currentUser.name,
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    onAddItem(newItem);
    setNewItemName('');
    setShowAddModal(false);
    setSyncToast('Nuevo registro guardado y sincronizado en la Nube');
    setTimeout(() => setSyncToast(null), 2500);
  };

  const filteredItems = items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`w-full p-4 pb-24 ${containerClasses}`}>
      {/* Sync feedback notification */}
      {syncToast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-full bg-emerald-600 border border-emerald-400 text-white font-extrabold text-xs flex items-center gap-2 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200">
          <Check className="w-4 h-4 text-emerald-200" strokeWidth={3} />
          <span>{syncToast}</span>
        </div>
      )}

      <div className="max-w-md mx-auto space-y-4">
        
        {/* Banner with Title and Add Button */}
        <div className="flex items-center justify-between pt-1">
          <div>
            <h1 className="text-xl font-extrabold tracking-tight uppercase">
              {config.name}
            </h1>
            <p className={`text-xs ${secondaryTextClasses}`}>
              {items.length} registros sincronizados con Google Drive
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleConsolidatedPDF}
              disabled={isConsolidatedLoading}
              title="Descargar reporte consolidado de todos los registros en PDF"
              className="min-h-[40px] px-3 rounded-xl bg-red-700 hover:bg-red-600 active:bg-red-800 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
            >
              {isConsolidatedLoading ? (
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              <span className="hidden sm:inline">CONSOLIDADO</span>
              <span>PDF</span>
            </button>

            <button
              onClick={() => setShowAddModal(true)}
              className="min-h-[40px] px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>AGREGAR</span>
            </button>
          </div>
        </div>

        {/* Quick Search Bar */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por nombre o código..."
            className={`w-full pl-9 pr-4 py-2.5 rounded-xl text-xs outline-none transition-all ${
              isObrero
                ? 'bg-white border border-sky-200 text-slate-800 placeholder-slate-400 focus:border-blue-500'
                : 'bg-white/10 border border-white/15 text-white placeholder-slate-400 focus:border-blue-400'
            }`}
          />
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        </div>

        {/* Add Modal */}
        {showAddModal && (
          <div className="p-4 rounded-2xl bg-blue-900/30 border border-blue-500/40 text-white space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-300">
              Nuevo Registro en {config.name}
            </h3>
            <form onSubmit={handleCreateNewItem} className="space-y-2">
              <input
                type="text"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                placeholder="Nombre del proyecto, personal o trabajo..."
                className={`w-full px-3 py-2 rounded-xl text-xs outline-none ${inputClasses}`}
                autoFocus
              />
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:bg-white/10"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold"
                >
                  Guardar
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Central List */}
        <div className="space-y-3">
          {filteredItems.map((item) => {
            const isEditing = editingId === item.id;
            const isDownloading = downloadingId === item.id;

            return (
              <div
                key={item.id}
                className={`rounded-2xl p-4 transition-all duration-150 ${cardClasses}`}
              >
                {/* Header row: Indicator Dot + Code + Status */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    {/* Status Dot */}
                    <span
                      className={`w-3 h-3 rounded-full shrink-0 ${
                        item.status === 'activo'
                          ? 'bg-emerald-500 shadow-sm shadow-emerald-500/50'
                          : item.status === 'en_progreso'
                          ? 'bg-sky-500 shadow-sm shadow-sky-500/50'
                          : item.status === 'completado'
                          ? 'bg-blue-600'
                          : 'bg-amber-500'
                      }`}
                    />
                    <span className="font-mono text-[11px] font-bold tracking-tight opacity-75">
                      {item.code}
                    </span>
                  </div>

                  <span className={`text-[10px] font-bold uppercase tracking-wider ${
                    isObrero ? 'text-sky-800' : 'text-sky-300'
                  }`}>
                    {item.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Name area: display or editable input */}
                <div className="mb-3">
                  {isEditing ? (
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="text"
                        value={tempName}
                        onChange={(e) => setTempName(e.target.value)}
                        className={`flex-1 px-3 py-2 rounded-xl text-sm font-semibold outline-none ring-2 ring-amber-400 ${inputClasses}`}
                        autoFocus
                      />
                      <button
                        onClick={() => handleSaveEdit(item.id)}
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-emerald-600 text-white hover:bg-emerald-500 active:scale-95 shadow-md"
                        title="Guardar nombre"
                      >
                        <Check className="w-5 h-5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-start justify-between gap-2 group">
                      <h2 className="text-sm sm:text-base font-bold leading-snug">
                        {item.name}
                      </h2>
                      <button
                        onClick={() => handleStartEdit(item)}
                        aria-label="Editar nombre"
                        className="p-1 rounded-lg text-slate-400 hover:text-amber-400 transition-colors shrink-0"
                        title="Editar nombre"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Subtitle / Details info */}
                <p className={`text-xs line-clamp-2 mb-3 leading-relaxed ${secondaryTextClasses}`}>
                  {item.details}
                </p>

                {/* Bottom Row inside card: Location + PDF Download Button */}
                <div className="pt-2 border-t border-black/10 dark:border-white/10 flex items-center justify-between gap-2">
                  <div className={`text-[11px] truncate ${secondaryTextClasses}`}>
                    📍 {item.location || 'Frente de Obra'}
                  </div>

                  {/* PDF Download Button */}
                  <button
                    onClick={() => handleDownloadPDF(item)}
                    disabled={isDownloading}
                    className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-red-600/20 active:scale-95 transition-all shrink-0"
                  >
                    {isDownloading ? (
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    <span>PDF</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Button: ABRIR DRIVE (mandatory at the end of the list) */}
        <div className="pt-4">
          <button
            onClick={handleOpenDrive}
            className="w-full min-h-[52px] py-3.5 px-4 rounded-2xl bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-extrabold text-sm tracking-wider uppercase shadow-xl flex items-center justify-center gap-2.5 active:scale-[0.98] transition-all"
          >
            <Folder className="w-5 h-5 text-amber-300" />
            <span>ABRIR DRIVE</span>
            <ExternalLink className="w-4 h-4 opacity-80" />
          </button>
          <p className="text-[10px] text-center mt-2 opacity-60">
            Abre la carpeta original compartida en Google Drive
          </p>
        </div>

      </div>

      {/* Interactive PDF Generation & Preview Modal */}
      {selectedItemForPDF && (
        <PDFExportModal
          item={selectedItemForPDF}
          role={role}
          currentUser={currentUser}
          isOpen={true}
          onClose={() => setSelectedItemForPDF(null)}
        />
      )}
    </div>
  );
};

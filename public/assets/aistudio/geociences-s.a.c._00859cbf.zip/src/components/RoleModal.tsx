import React, { useState } from 'react';
import { ArrowLeft, Edit3, Save, CheckCircle2, UserCheck, Plus, Trash2 } from 'lucide-react';
import { UserRole, RoleResponsibility } from '../types';

interface RoleModalProps {
  role: UserRole;
  data: RoleResponsibility;
  onSave: (updated: RoleResponsibility) => void;
  onBack: () => void;
}

export const RoleModal: React.FC<RoleModalProps> = ({ role, data, onSave, onBack }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [summary, setSummary] = useState(data.summary);
  const [responsibilities, setResponsibilities] = useState<string[]>(data.responsibilities);
  const [newResp, setNewResp] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleAddResponsibility = () => {
    if (!newResp.trim()) return;
    setResponsibilities([...responsibilities, newResp.trim()]);
    setNewResp('');
  };

  const handleRemoveResponsibility = (index: number) => {
    setResponsibilities(responsibilities.filter((_, i) => i !== index));
  };

  const handleSaveAll = () => {
    const updated: RoleResponsibility = {
      ...data,
      summary: summary.trim(),
      responsibilities,
      lastUpdated: new Date().toISOString().substring(0, 10),
    };
    onSave(updated);
    setIsEditing(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col pb-24">
      {/* Header Bar */}
      <div className="sticky top-0 z-20 bg-slate-900 border-b border-slate-800 px-4 py-3 shadow-md">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              aria-label="Regresar"
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 active:scale-95 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-sm font-extrabold uppercase tracking-wide text-white">
                ROL Y RESPONSABILIDADES
              </h1>
              <p className="text-[11px] text-blue-400 font-semibold">
                {role}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (isEditing) {
                handleSaveAll();
              } else {
                setIsEditing(true);
              }
            }}
            className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
          >
            {isEditing ? (
              <>
                <Save className="w-3.5 h-3.5" />
                <span>GUARDAR</span>
              </>
            ) : (
              <>
                <Edit3 className="w-3.5 h-3.5" />
                <span>EDITAR</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 max-w-md w-full mx-auto p-4 space-y-4">
        
        {/* Saved Success Banner */}
        {savedSuccess && (
          <div className="p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Responsabilidades del cargo actualizadas con éxito.</span>
          </div>
        )}

        {/* Title Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white">
                {data.title}
              </h2>
              <span className="text-[10px] text-slate-400 uppercase tracking-widest">
                GEOCIENCES S.A.C. · Última revisión: {data.lastUpdated}
              </span>
            </div>
          </div>

          {/* Summary */}
          {isEditing ? (
            <div>
              <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">
                Resumen Ejecutivo
              </label>
              <textarea
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-amber-400 text-xs text-white outline-none focus:ring-1 focus:ring-amber-400"
              />
            </div>
          ) : (
            <p className="text-xs text-slate-300 leading-relaxed pt-1 border-t border-slate-800">
              {summary}
            </p>
          )}
        </div>

        {/* Responsibilities list */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-200">
            Funciones Principales y Alcance
          </h3>

          <div className="space-y-2.5">
            {responsibilities.map((resp, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 group"
              >
                <span className="w-5 h-5 rounded-full bg-blue-600/30 border border-blue-500/40 text-blue-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <p className="flex-1 text-xs text-slate-200 leading-relaxed">
                  {resp}
                </p>
                {isEditing && (
                  <button
                    onClick={() => handleRemoveResponsibility(idx)}
                    className="text-slate-500 hover:text-red-400 p-1 shrink-0"
                    title="Eliminar"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Add new responsibility when editing */}
          {isEditing && (
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <label className="block text-[11px] font-bold text-slate-400 uppercase">
                Agregar Nueva Responsabilidad
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newResp}
                  onChange={(e) => setNewResp(e.target.value)}
                  placeholder="Descripción de la función..."
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddResponsibility}
                  className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shrink-0 flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>Añadir</span>
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

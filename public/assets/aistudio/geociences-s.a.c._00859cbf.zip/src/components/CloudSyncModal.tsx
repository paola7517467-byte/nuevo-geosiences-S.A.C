import React, { useState, useEffect } from 'react';
import {
  Cloud,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  Copy,
  Check,
  FileCode,
  Download,
  Upload,
  HardDrive,
  FolderGit2,
  AlertCircle,
  X,
  Server,
  Database,
  ArrowRight,
} from 'lucide-react';
import { UserRole, UserProfile } from '../types';
import { DRIVE_CONFIG } from '../data/initialData';
import {
  getCloudConfig,
  saveCloudConfig,
  getSyncEvents,
  testWebhookConnection,
  generateFullBackup,
  restoreFromBackup,
  GOOGLE_APPS_SCRIPT_TEMPLATE,
  SyncEvent,
  CloudConfig,
} from '../services/cloudSync';

interface CloudSyncModalProps {
  isOpen: boolean;
  role: UserRole;
  user: UserProfile;
  onClose: () => void;
  onForceSync: () => Promise<void>;
  isSyncing: boolean;
  lastSyncTime: string;
}

export const CloudSyncModal: React.FC<CloudSyncModalProps> = ({
  isOpen,
  role,
  user,
  onClose,
  onForceSync,
  isSyncing,
  lastSyncTime,
}) => {
  const [config, setConfig] = useState<CloudConfig>(() => getCloudConfig());
  const [webhookInput, setWebhookInput] = useState<string>('');
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [events, setEvents] = useState<SyncEvent[]>(() => getSyncEvents());
  const [activeTab, setActiveTab] = useState<'estado' | 'configuracion' | 'codigo' | 'historial'>('estado');
  const [copiedCode, setCopiedCode] = useState(false);
  const [backupNotice, setBackupNotice] = useState<string | null>(null);

  const driveConfig = DRIVE_CONFIG[role];

  useEffect(() => {
    if (isOpen) {
      const currentConfig = getCloudConfig();
      setConfig(currentConfig);
      setWebhookInput(currentConfig.webhookUrl || '');
      setEvents(getSyncEvents());
      setTestResult(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveWebhook = () => {
    const updated = { ...config, webhookUrl: webhookInput.trim() };
    setConfig(updated);
    saveCloudConfig(updated);
    setTestResult({
      ok: true,
      message: 'URL de Webhook guardada exitosamente.',
    });
    setTimeout(() => setTestResult(null), 3000);
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testWebhookConnection(webhookInput);
      setTestResult(res);
    } finally {
      setIsTesting(false);
    }
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(GOOGLE_APPS_SCRIPT_TEMPLATE);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    } catch (e) {
      console.warn('Clipboard write failed', e);
    }
  };

  const handleDownloadBackup = () => {
    const jsonStr = generateFullBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `GEOCIENCES_BACKUP_TOTAL_${new Date().toISOString().substring(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setBackupNotice('Copia descargada correctamente');
    setTimeout(() => setBackupNotice(null), 3000);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      if (content) {
        const ok = restoreFromBackup(content);
        if (ok) {
          setBackupNotice('Copia restaurada exitosamente. Recarga la app para ver los cambios.');
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        } else {
          setBackupNotice('El archivo no es una copia de seguridad válida.');
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        aria-hidden="true"
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-700 rounded-2xl text-white shadow-2xl flex flex-col max-h-[90vh] z-10 overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <Cloud className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="font-extrabold text-sm sm:text-base uppercase tracking-wide text-white">
                Sincronización en la Nube
              </h2>
              <p className="text-[11px] text-amber-400 font-medium">
                GEOCIENCES S.A.C. &bull; Google Drive
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Cerrar modal de sincronización"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-4 border-b border-neutral-800 bg-neutral-950/80 text-xs font-bold">
          <button
            onClick={() => setActiveTab('estado')}
            className={`py-3 text-center border-b-2 transition-colors ${
              activeTab === 'estado'
                ? 'border-blue-500 text-blue-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            ESTADO
          </button>
          <button
            onClick={() => setActiveTab('configuracion')}
            className={`py-3 text-center border-b-2 transition-colors ${
              activeTab === 'configuracion'
                ? 'border-blue-500 text-blue-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            WEBHOOK
          </button>
          <button
            onClick={() => setActiveTab('codigo')}
            className={`py-3 text-center border-b-2 transition-colors ${
              activeTab === 'codigo'
                ? 'border-blue-500 text-blue-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            CÓDIGO .GS
          </button>
          <button
            onClick={() => setActiveTab('historial')}
            className={`py-3 text-center border-b-2 transition-colors ${
              activeTab === 'historial'
                ? 'border-blue-500 text-blue-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            HISTORIAL
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar text-xs">
          {/* TAB 1: ESTADO */}
          {activeTab === 'estado' && (
            <div className="space-y-4">
              {/* Architecture Explanation Card */}
              <div className="p-3.5 bg-neutral-950/80 rounded-xl border border-neutral-800 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase">
                  <Database className="w-4 h-4" />
                  ¿Dónde se guarda todo lo que editas?
                </div>
                <p className="text-neutral-300 leading-relaxed">
                  Todos los cambios realizados en <strong>proyectos</strong>,{' '}
                  <strong>personal</strong>, <strong>hojas de cálculo Excel</strong>,{' '}
                  <strong>marcaciones GPS</strong> y <strong>perfil</strong> se almacenan en:
                </p>
                <div className="space-y-2 pt-1">
                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 flex items-start gap-2.5">
                    <HardDrive className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-neutral-100">1. Almacenamiento Local Seguro (Offline-First)</p>
                      <p className="text-[11px] text-neutral-400">
                        Guardado automático e instantáneo en tu móvil. Si estás en obra sin señal o sin internet,
                        ningún dato se pierde.
                      </p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 flex items-start gap-2.5">
                    <Cloud className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-neutral-100">2. Espejo Cloud Permanente</p>
                      <p className="text-[11px] text-neutral-400">
                        Los datos se unifican bajo tu usuario ({user.email}) y cargo ({role}) con marcas de tiempo auditables.
                      </p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 flex items-start gap-2.5">
                    <FolderGit2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-neutral-100">3. Google Drive & Google Sheets (Vía Webhook)</p>
                      <p className="text-[11px] text-neutral-400">
                        Sincronización directa con las carpetas y hojas de cálculo oficiales mediante Google Apps Script.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status Overview Card */}
              <div className="p-4 bg-gradient-to-br from-neutral-950 to-neutral-900 rounded-xl border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-neutral-300 uppercase">Estado del Sistema:</span>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold text-[11px]">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    CONECTADO & SEGURO
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2.5 bg-neutral-900/90 rounded-lg border border-neutral-800">
                    <p className="text-neutral-400">Última Sincronización:</p>
                    <p className="font-bold text-white mt-0.5">{lastSyncTime || 'Al instante'}</p>
                  </div>
                  <div className="p-2.5 bg-neutral-900/90 rounded-lg border border-neutral-800">
                    <p className="text-neutral-400">Destino Drive:</p>
                    <p className="font-bold text-amber-400 mt-0.5 truncate">{driveConfig.label}</p>
                  </div>
                </div>

                {/* Force sync button */}
                <button
                  onClick={async () => {
                    await onForceSync();
                    setEvents(getSyncEvents());
                  }}
                  disabled={isSyncing}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 active:scale-[0.98] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40 transition-all disabled:opacity-60"
                >
                  <RefreshCw className={`w-5 h-5 ${isSyncing ? 'animate-spin' : ''}`} />
                  {isSyncing ? 'SINCRONIZANDO CON LA NUBE...' : 'SINCRONIZAR AHORA CON LA NUBE'}
                </button>
              </div>

              {/* Links to Google Drive */}
              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <p className="font-bold text-neutral-300 uppercase text-[11px]">Accesos Oficiales de tu Cargo ({role}):</p>
                <div className="space-y-1.5">
                  <a
                    href={driveConfig.mainFolder}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    <span className="truncate">Carpeta Principal: {driveConfig.name}</span>
                    <ExternalLink className="w-4 h-4 shrink-0 ml-2" />
                  </a>
                  <a
                    href={driveConfig.excelFolder}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-emerald-400 hover:text-emerald-300 transition-colors"
                  >
                    <span className="truncate">Hojas de Cálculo Excel ({role})</span>
                    <ExternalLink className="w-4 h-4 shrink-0 ml-2" />
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CONFIGURACIÓN WEBHOOK */}
          {activeTab === 'configuracion' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase">
                  <Server className="w-4 h-4" />
                  URL de Google Apps Script Webhook
                </div>
                <p className="text-neutral-300 text-[11px] leading-relaxed">
                  Conecta la app directamente con tu hoja de cálculo en Google Drive.
                  Pega aquí la URL de tu aplicación web (terminada en <code>/exec</code>) generada desde Apps Script:
                </p>

                <div className="space-y-2 pt-1">
                  <input
                    type="url"
                    value={webhookInput}
                    onChange={(e) => setWebhookInput(e.target.value)}
                    placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 text-white font-mono text-[11px] focus:outline-none focus:border-blue-500"
                  />

                  <div className="flex gap-2">
                    <button
                      onClick={handleSaveWebhook}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 font-bold text-white text-xs flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      GUARDAR URL
                    </button>
                    <button
                      onClick={handleTestConnection}
                      disabled={isTesting || !webhookInput}
                      className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 font-bold text-neutral-200 text-xs flex items-center justify-center gap-1.5 border border-neutral-700 disabled:opacity-50"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                      PROBAR
                    </button>
                  </div>
                </div>

                {testResult && (
                  <div
                    className={`p-2.5 rounded-lg border text-[11px] flex items-start gap-2 ${
                      testResult.ok
                        ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                        : 'bg-red-950/60 border-red-500/40 text-red-300'
                    }`}
                  >
                    {testResult.ok ? (
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
                    )}
                    <span>{testResult.message}</span>
                  </div>
                )}
              </div>

              {/* Instructions summary */}
              <div className="p-3.5 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <p className="font-bold text-amber-400 uppercase text-[11px]">¿Cómo obtener tu Webhook en 3 minutos?</p>
                <ol className="list-decimal list-inside space-y-1.5 text-neutral-300 text-[11px]">
                  <li>Ve a la pestaña <strong>CÓDIGO .GS</strong> y copia el script completo.</li>
                  <li>Abre tu Google Sheets o tu carpeta en Google Drive.</li>
                  <li>Haz clic en <strong>Extensiones &gt; Apps Script</strong> y pega el código.</li>
                  <li>Haz clic en <strong>Implementar &gt; Nueva implementación</strong>.</li>
                  <li>Tipo: <em>Aplicación web</em>, Acceso: <em>Cualquier usuario</em>.</li>
                  <li>Copia la URL generada y pégala arriba.</li>
                </ol>
              </div>

              {/* Backup section */}
              <div className="p-3.5 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <p className="font-bold text-neutral-300 uppercase text-[11px]">Copia de Seguridad Manual (JSON)</p>
                <div className="flex gap-2">
                  <button
                    onClick={handleDownloadBackup}
                    className="flex-1 py-2 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold flex items-center justify-center gap-1.5 border border-neutral-700"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-400" />
                    EXPORTAR BACKUP
                  </button>
                  <label className="flex-1 py-2 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold flex items-center justify-center gap-1.5 border border-neutral-700 cursor-pointer">
                    <Upload className="w-3.5 h-3.5 text-amber-400" />
                    RESTAURAR
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleRestoreFile}
                      className="hidden"
                    />
                  </label>
                </div>
                {backupNotice && (
                  <p className="text-[11px] text-amber-400 font-semibold pt-1">{backupNotice}</p>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: CÓDIGO GOOGLE APPS SCRIPT */}
          {activeTab === 'codigo' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-neutral-200 text-xs">Script Oficial para Google Sheets</h3>
                  <p className="text-[10px] text-neutral-400">Automatiza la recepción y guardado en Drive</p>
                </div>
                <button
                  onClick={handleCopyCode}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors ${
                    copiedCode
                      ? 'bg-emerald-600 text-white'
                      : 'bg-blue-600 hover:bg-blue-500 text-white'
                  }`}
                >
                  {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copiedCode ? '¡COPIADO!' : 'COPIAR CÓDIGO'}
                </button>
              </div>

              <div className="relative rounded-xl bg-black border border-neutral-800 overflow-hidden">
                <div className="p-2 bg-neutral-950 border-b border-neutral-800 text-[10px] font-mono text-neutral-400 flex items-center justify-between">
                  <span>Code.gs &bull; GEOCIENCES S.A.C. Sync</span>
                  <span className="text-amber-400 font-bold">JavaScript / Apps Script</span>
                </div>
                <pre className="p-3 text-[10px] font-mono text-slate-300 overflow-x-auto max-h-64 leading-relaxed">
                  {GOOGLE_APPS_SCRIPT_TEMPLATE}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 4: HISTORIAL DE SINCRONIZACIONES */}
          {activeTab === 'historial' && (
            <div className="space-y-2">
              <p className="font-bold text-neutral-400 uppercase text-[10px]">
                Últimos Eventos de Sincronización ({events.length})
              </p>
              {events.length === 0 ? (
                <div className="p-6 text-center text-neutral-500">
                  No hay registros de sincronización aún.
                </div>
              ) : (
                <div className="space-y-2">
                  {events.map((evt) => (
                    <div
                      key={evt.id}
                      className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-start gap-2.5"
                    >
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                          evt.status === 'success'
                            ? 'bg-emerald-950 border border-emerald-500/40 text-emerald-400'
                            : 'bg-amber-950 border border-amber-500/40 text-amber-400'
                        }`}
                      >
                        {evt.status === 'success' ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : (
                          <RefreshCw className="w-4 h-4 animate-spin" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <p className="font-bold text-neutral-100 text-[11px] truncate">{evt.action}</p>
                          <span className="text-[10px] text-neutral-400 font-mono shrink-0">
                            {evt.timestamp}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 mt-0.5">{evt.details}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <span className="text-[10px] text-neutral-400">
            GEOCIENCES S.A.C. &bull; Sistema Cloud v1.2
          </span>
          <button
            onClick={onClose}
            className="py-2 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs"
          >
            CERRAR
          </button>
        </div>
      </div>
    </div>
  );
};

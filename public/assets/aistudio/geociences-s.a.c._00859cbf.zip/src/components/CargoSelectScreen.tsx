import React from 'react';
import { Briefcase, Building2, HardHat, Wrench, Shield, ArrowLeft } from 'lucide-react';
import { UserRole, UserProfile } from '../types';

interface CargoSelectScreenProps {
  onSelectRole: (role: UserRole) => void;
  currentUser: UserProfile;
  onBackToLogin: () => void;
}

export const CargoSelectScreen: React.FC<CargoSelectScreenProps> = ({
  onSelectRole,
  currentUser,
  onBackToLogin,
}) => {
  const roles: {
    id: UserRole;
    title: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    colorClass: string;
    borderClass: string;
    bgAccent: string;
  }[] = [
    {
      id: 'GERENTE',
      title: '1. GERENTE',
      description: 'Dirección Estratégica, Contratos y Decisiones Globales',
      icon: Briefcase,
      colorClass: 'text-amber-400',
      borderClass: 'border-neutral-800 hover:border-amber-500/60',
      bgAccent: 'bg-neutral-900/90 active:bg-neutral-800',
    },
    {
      id: 'ADMINISTRADOR',
      title: '2. ADMINISTRADOR',
      description: 'Personal, Recursos Humanos, Logística y Finanzas',
      icon: Building2,
      colorClass: 'text-slate-300',
      borderClass: 'border-slate-700 hover:border-slate-500',
      bgAccent: 'bg-slate-800/80 active:bg-slate-700',
    },
    {
      id: 'RESIDENTE',
      title: '3. RESIDENTE',
      description: 'Ingeniería en Obra, Control Geotécnico y Calidad',
      icon: HardHat,
      colorClass: 'text-sky-400',
      borderClass: 'border-sky-900/80 hover:border-sky-500',
      bgAccent: 'bg-sky-950/70 active:bg-sky-900',
    },
    {
      id: 'OBRERO',
      title: '4. OBRERO',
      description: 'Operaciones en Campo, Ensayos, Muestreo y Seguridad',
      icon: Wrench,
      colorClass: 'text-emerald-400',
      borderClass: 'border-emerald-900/80 hover:border-emerald-500',
      bgAccent: 'bg-neutral-900 active:bg-neutral-800',
    },
  ];

  return (
    <div className="min-h-screen w-full bg-black text-white p-4 flex flex-col justify-between">
      {/* Top Bar with Back and Company */}
      <div className="max-w-md w-full mx-auto pt-2 pb-4 flex items-center justify-between border-b border-neutral-900">
        <button
          onClick={onBackToLogin}
          className="min-h-[44px] px-3 flex items-center gap-1.5 rounded-xl text-xs font-semibold text-neutral-400 hover:text-white hover:bg-neutral-900 active:scale-95 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Volver</span>
        </button>
        <span className="text-xs font-extrabold tracking-wider text-neutral-400">
          GEOCIENCES S.A.C.
        </span>
      </div>

      {/* Main Content */}
      <div className="max-w-md w-full mx-auto my-auto py-6">
        {/* Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-[11px] font-bold text-neutral-400 uppercase tracking-widest mb-3">
            <Shield className="w-3.5 h-3.5 text-blue-400" />
            Acceso Autorizado: {currentUser.name}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white uppercase">
            SELECCIONAR CARGO
          </h1>
          <p className="text-xs text-neutral-400 mt-1.5">
            Presione su nivel de acceso institucional para cargar su panel correspondiente.
          </p>
        </div>

        {/* 4 Large Tactile Buttons */}
        <div className="space-y-3.5">
          {roles.map((r) => {
            const Icon = r.icon;
            return (
              <button
                key={r.id}
                onClick={() => onSelectRole(r.id)}
                className={`w-full min-h-[74px] p-4 rounded-2xl border ${r.borderClass} ${r.bgAccent} shadow-lg transition-all transform active:scale-[0.98] flex items-center gap-4 text-left group`}
              >
                <div
                  className={`w-12 h-12 rounded-xl bg-black/60 border border-white/10 flex items-center justify-center shrink-0 ${r.colorClass}`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-base font-extrabold tracking-wide text-white group-hover:text-blue-400 transition-colors">
                    {r.title}
                  </div>
                  <div className="text-xs text-neutral-400 line-clamp-1 mt-0.5">
                    {r.description}
                  </div>
                </div>
                <div className="w-7 h-7 rounded-full bg-white/5 flex items-center justify-center text-neutral-400 group-hover:text-white group-hover:bg-blue-600 transition-colors shrink-0">
                  <span className="text-xs font-bold">→</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Footer info */}
      <div className="max-w-md w-full mx-auto pb-4 text-center">
        <p className="text-[11px] text-neutral-500">
          Los permisos y accesos a Google Drive están vinculados a cada perfil.
        </p>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { ArrowLeft, ShieldAlert, FileText, CheckCircle2, Lock } from 'lucide-react';
import { UserRole } from '../types';
import { SECURITY_PROTOCOLS } from '../data/initialData';

interface ProtocolosModalProps {
  role: UserRole;
  onBack: () => void;
}

export const ProtocolosModal: React.FC<ProtocolosModalProps> = ({ role, onBack }) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>(role);
  const protocol = SECURITY_PROTOCOLS[selectedRole];

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col pb-24">
      {/* Header Bar */}
      <div className="sticky top-0 z-20 bg-slate-900 border-b border-slate-800 px-4 py-3 shadow-md">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              aria-label="Regresar"
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 active:scale-95 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-sm font-extrabold uppercase tracking-wide text-white">
                PROTOCOLOS DE SEGURIDAD
              </h1>
              <p className="text-[11px] text-amber-400 font-semibold">
                Normas Institucionales SSOMA
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-[10px] font-bold text-slate-300">
            <Lock className="w-3 h-3 text-amber-400" />
            <span>Oficial</span>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 max-w-md w-full mx-auto p-4 space-y-4">
        
        {/* Compliance Badge */}
        <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-600/40 flex items-center gap-3">
          <ShieldAlert className="w-6 h-6 text-amber-400 shrink-0" />
          <div className="text-xs">
            <p className="font-bold text-amber-200">
              Cumplimiento Obligatorio · Ley 29783 & Norma G.050
            </p>
            <p className="text-[11px] text-amber-300/80 mt-0.5">
              Protocolo institucional no editable por los trabajadores en campo.
            </p>
          </div>
        </div>

        {/* Cargo Selector Tabs */}
        <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800">
          {(['GERENTE', 'ADMINISTRADOR', 'RESIDENTE', 'OBRERO'] as UserRole[]).map((r) => (
            <button
              key={r}
              onClick={() => setSelectedRole(r)}
              className={`py-2 text-[10px] font-extrabold rounded-lg tracking-wider uppercase transition-all ${
                selectedRole === r
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {r.substring(0, 4)}
            </button>
          ))}
        </div>

        {/* Protocol Document Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div className="border-b border-slate-800 pb-3 flex items-start justify-between gap-3">
            <div>
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest block mb-1">
                GEOCIENCES S.A.C. · SSOMA DIRECTIVA N° 04-2026
              </span>
              <h2 className="text-sm font-extrabold text-white leading-tight">
                {protocol.title}
              </h2>
            </div>
            <div className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[10px] text-slate-400 shrink-0 text-center">
              <span>{protocol.wordCount}</span>
              <span className="block text-[8px] text-slate-500 uppercase">palabras</span>
            </div>
          </div>

          {/* Text Content */}
          <div className="text-xs sm:text-sm text-slate-300 leading-relaxed space-y-3.5 whitespace-pre-line font-sans">
            {protocol.content}
          </div>

          {/* Signoff verification */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Vigente para el Ejercicio 2026</span>
            </div>
            <span>Comité de Seguridad CSST</span>
          </div>
        </div>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  FileText,
  Download,
  Share2,
  X,
  CheckCircle2,
  MapPin,
  PenTool,
  Calendar,
  Building,
  User,
  ShieldAlert,
} from 'lucide-react';
import { ListItem, UserRole, UserProfile, GPSRecord } from '../types';
import { generatePDFReport } from '../services/pdfGenerator';
import { loadGPSRecords } from '../services/storage';

interface PDFExportModalProps {
  item: ListItem;
  role: UserRole;
  currentUser: UserProfile;
  isOpen: boolean;
  onClose: () => void;
}

export const PDFExportModal: React.FC<PDFExportModalProps> = ({
  item,
  role,
  currentUser,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [reportType, setReportType] = useState<string>(() =>
    role === 'ADMINISTRADOR'
      ? 'FICHA TÉCNICA Y EVALUACIÓN DE PERSONAL'
      : role === 'OBRERO'
      ? 'REPORTE OPERATIVO DE CAMPO Y TRABAJOS DE OBRA'
      : 'INFORME DE CONTROL GEOTÉCNICO Y SUPERVISIÓN'
  );

  const [customObservations, setCustomObservations] = useState(
    'El presente documento certifica la ejecución y conformidad técnica conforme a las normas de GEOCIENCES S.A.C., directrices ASTM y la Norma Técnica G.050 de Seguridad durante la Construcción.'
  );

  const [includeGPS, setIncludeGPS] = useState(true);
  const [includePersonnelSignature, setIncludePersonnelSignature] = useState(role === 'ADMINISTRADOR');
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Get most recent GPS record if available
  const recentGps: GPSRecord | null = loadGPSRecords()[0] || null;

  const handleDownload = () => {
    setIsDownloading(true);
    setDownloadSuccess(false);

    try {
      const signers = [
        { label: 'GERENCIA GENERAL', sublabel: 'GEOCIENCES S.A.C.' },
        { label: 'RESIDENCIA DE OBRA', sublabel: 'Colegio de Ingenieros (CIP)' },
        { label: 'SUPERVISIÓN SSOMA', sublabel: 'Seguridad y Salud Ocupacional' },
      ];

      if (includePersonnelSignature) {
        signers.push({ label: 'INTERESADO / PERSONAL', sublabel: 'Conformidad de Recepción' });
      }

      generatePDFReport(item, role, currentUser.name, {
        reportType,
        customObservations,
        includeGPS,
        gpsRecord: recentGps,
        signers,
      });

      setDownloadSuccess(true);
      setTimeout(() => {
        setDownloadSuccess(false);
      }, 3500);
    } catch (err) {
      console.error('Error generating PDF', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Reporte GEOCIENCES S.A.C. - ${item.name}`,
          text: `Informe técnico oficial para ${item.name} (${item.code}). Generado por ${currentUser.name}.`,
          url: window.location.href,
        });
      } catch (err) {
        console.log('Share canceled or failed', err);
      }
    } else {
      // Fallback: trigger download
      handleDownload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg max-h-[92vh] bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        
        {/* Modal Top Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold uppercase tracking-wide text-white">
                GENERADOR DE REPORTE PDF
              </h2>
              <span className="text-[10px] text-slate-400 font-mono">
                GEOCIENCES S.A.C. · Membrete Oficial
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Cerrar ventana"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 active:scale-95 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Document Preview & Configuration */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          
          {/* Success banner */}
          {downloadSuccess && (
            <div className="p-3 rounded-2xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-2 shadow-lg animate-in fade-in duration-200">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>
                ¡Reporte PDF generado y descargado exitosamente en su dispositivo móvil!
              </span>
            </div>
          )}

          {/* Interactive Document Preview Box */}
          <div className="p-4 rounded-2xl bg-white text-slate-900 border border-slate-200 shadow-xl space-y-3">
            {/* Header Mockup */}
            <div className="p-3 rounded-xl bg-slate-950 text-white flex items-center justify-between">
              <div>
                <span className="font-extrabold text-sm tracking-wider text-white block">
                  GEOCIENCES S.A.C.
                </span>
                <span className="text-[9px] text-slate-300 uppercase tracking-widest">
                  Consultoría e Ingeniería Civil
                </span>
              </div>
              <div className="text-right">
                <span className="text-[9px] px-2 py-0.5 rounded bg-blue-700 text-white font-bold block uppercase">
                  {item.code}
                </span>
                <span className="text-[8px] text-slate-400 mt-0.5 block">
                  RUC: 20601234567
                </span>
              </div>
            </div>

            {/* Selected Item Info in Preview */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[10px] font-bold uppercase text-slate-500">
                  Elemento Seleccionado:
                </span>
                <span className="text-[10px] font-bold text-emerald-600 uppercase">
                  {item.status.replace('_', ' ')}
                </span>
              </div>
              <h3 className="font-extrabold text-sm text-slate-950 leading-snug">
                {item.name}
              </h3>
              <p className="text-[11px] text-slate-600 line-clamp-2">
                {item.details}
              </p>
              <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between text-[10px] text-slate-500 gap-2">
                <span>📍 {item.location || 'Frente de Obra'}</span>
                <span>👤 {item.responsible || currentUser.name}</span>
                <span>📅 {new Date().toLocaleDateString('es-PE')}</span>
              </div>
            </div>

            {/* Space for Signatures Preview */}
            <div className="pt-2 border-t border-slate-200">
              <span className="text-[10px] font-extrabold uppercase text-slate-500 block mb-2">
                Espacios para Firmas Institucionales:
              </span>
              <div className="grid grid-cols-3 gap-2 text-center text-[9px] font-bold text-slate-700">
                <div className="p-2 border-t-2 border-slate-400 pt-1">
                  Gerencia General
                </div>
                <div className="p-2 border-t-2 border-slate-400 pt-1">
                  Residencia de Obra
                </div>
                <div className="p-2 border-t-2 border-slate-400 pt-1">
                  Supervisión SSOMA
                </div>
              </div>
            </div>
          </div>

          {/* Configuration Form */}
          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <PenTool className="w-3.5 h-3.5 text-amber-400" />
              <span>Personalizar Datos del Reporte</span>
            </h4>

            {/* Report Type Selector */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Título del Documento
              </label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-blue-500"
              >
                <option value="INFORME DE CONTROL GEOTÉCNICO Y SUPERVISIÓN">
                  Informe de Control Geotécnico y Supervisión
                </option>
                <option value="FICHA TÉCNICA Y EVALUACIÓN DE PERSONAL">
                  Ficha Técnica y Evaluación de Personal
                </option>
                <option value="REPORTE OPERATIVO DE CAMPO Y TRABAJOS DE OBRA">
                  Reporte Operativo de Campo y Trabajos de Obra
                </option>
                <option value="ACTA DE CONFORMIDAD Y ENSAYOS DE SUELOS">
                  Acta de Conformidad y Ensayos de Suelos
                </option>
              </select>
            </div>

            {/* Custom Observations */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Observaciones y Conclusiones
              </label>
              <textarea
                value={customObservations}
                onChange={(e) => setCustomObservations(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-blue-500"
              />
            </div>

            {/* Toggles */}
            <div className="space-y-2 pt-1 text-xs">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeGPS}
                  onChange={(e) => setIncludeGPS(e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-0"
                />
                <span className="text-slate-300">
                  Incluir coordenadas GPS geodésicas de obra
                </span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includePersonnelSignature}
                  onChange={(e) => setIncludePersonnelSignature(e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-0"
                />
                <span className="text-slate-300">
                  Incluir espacio de firma del trabajador / colaborador
                </span>
              </label>
            </div>
          </div>

        </div>

        {/* Modal Actions Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center gap-2 shrink-0">
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="w-full sm:flex-1 min-h-[50px] py-3.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 active:bg-red-700 text-white font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            {isDownloading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            <span>DESCARGAR PDF DIRECTO EN EL MÓVIL</span>
          </button>

          <button
            onClick={handleShare}
            className="w-full sm:w-auto min-h-[50px] py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase tracking-wider border border-slate-700 flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>Compartir</span>
          </button>
        </div>

      </div>
    </div>
  );
};

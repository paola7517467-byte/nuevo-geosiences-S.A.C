import React from 'react';
import { Menu, Home, Cloud } from 'lucide-react';
import { UserRole } from '../types';
import { DRIVE_CONFIG } from '../data/initialData';

interface TopBarProps {
  role: UserRole;
  onOpenMenu: () => void;
  onGoHome: () => void;
  onOpenCloudSync: () => void;
  isSyncing?: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  role,
  onOpenMenu,
  onGoHome,
  onOpenCloudSync,
  isSyncing = false,
}) => {
  const config = DRIVE_CONFIG[role];

  // Specific header styling per role instructions
  // Gerente: black corporate
  // Administrador: gray corporate
  // Residente: dark sky blue
  // Obrero: pastel sky blue with dark text
  const headerClass =
    role === 'GERENTE'
      ? 'bg-neutral-950 border-b border-neutral-800 text-white'
      : role === 'ADMINISTRADOR'
      ? 'bg-slate-900 border-b border-slate-700 text-slate-100'
      : role === 'RESIDENTE'
      ? 'bg-sky-950 border-b border-sky-800 text-white'
      : 'bg-sky-200 border-b border-sky-300 text-slate-900';

  const iconButtonClass =
    role === 'OBRERO'
      ? 'text-slate-800 hover:bg-sky-300 active:bg-sky-400'
      : 'text-white hover:bg-white/10 active:bg-white/20';

  return (
    <header className={`sticky top-0 z-30 w-full shadow-md transition-colors ${headerClass}`}>
      <div className="max-w-md mx-auto px-2 sm:px-3 py-2 flex items-center justify-between">
        {/* Left: Hamburger button with >=44px tap hitbox */}
        <button
          onClick={onOpenMenu}
          aria-label="Abrir Menú Lateral"
          className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-transform active:scale-95 ${iconButtonClass}`}
        >
          <Menu className="w-6 h-6" strokeWidth={2.5} />
        </button>

        {/* Center: Brand name */}
        <div className="flex flex-col items-center text-center px-1">
          <span className="font-extrabold tracking-wider text-sm sm:text-base uppercase whitespace-nowrap">
            GEOCIENCES S.A.C.
          </span>
          <span className="text-[10px] uppercase font-semibold tracking-widest opacity-80 whitespace-nowrap">
            {config.label}
          </span>
        </div>

        {/* Right: Cloud Sync Status + Home button ("Casita") */}
        <div className="flex items-center gap-0.5">
          <button
            onClick={onOpenCloudSync}
            title="Sincronización en la Nube y Google Drive"
            aria-label="Sincronización en la Nube"
            className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-transform active:scale-95 relative ${iconButtonClass}`}
          >
            <Cloud className={`w-5 h-5 ${isSyncing ? 'text-amber-400 animate-spin' : role === 'OBRERO' ? 'text-blue-700' : 'text-blue-400'}`} />
            <span
              className={`absolute top-2.5 right-2.5 w-2 h-2 rounded-full border border-neutral-900 ${
                isSyncing ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'
              }`}
            />
          </button>

          <button
            onClick={onGoHome}
            aria-label="Ir al Inicio"
            className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-transform active:scale-95 ${iconButtonClass}`}
          >
            <Home className="w-6 h-6" strokeWidth={2.5} />
          </button>
        </div>
      </div>
    </header>
  );
};

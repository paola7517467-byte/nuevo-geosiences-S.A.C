import React, { useState } from 'react';
import { Eye, EyeOff, ShieldCheck, AlertCircle, CheckCircle2, Shield, Info, ArrowRight, X } from 'lucide-react';
import { UserProfile } from '../types';
import { googleSignIn } from '../services/googleAuth';

interface LoginScreenProps {
  onSuccess: (email: string, isGoogle: boolean, name?: string, photoURL?: string) => void;
  currentUser: UserProfile;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onSuccess, currentUser }) => {
  const [email, setEmail] = useState(currentUser.email || '');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [googleConnected, setGoogleConnected] = useState(currentUser.isGoogleConnected || false);
  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation 1: Email must contain '@'
    if (!email || !email.includes('@')) {
      setError('Por favor ingrese un correo electrónico válido que contenga @.');
      return;
    }

    // Validation 2: Initial test password is 900308983
    if (password !== '900308983') {
      setError('Contraseña incorrecta. Por favor verifique sus credenciales de acceso.');
      return;
    }

    onSuccess(email, googleConnected);
  };

  const handleStartGoogleFlow = () => {
    setError(null);
    setShowPermissionPrompt(true);
  };

  const executeGoogleSignIn = async () => {
    setShowPermissionPrompt(false);
    setIsGoogleLoading(true);
    setError(null);

    try {
      const result = await googleSignIn();
      if (result) {
        setGoogleConnected(true);
        setEmail(result.email);
        onSuccess(
          result.email,
          true,
          result.displayName || undefined,
          result.photoURL || undefined
        );
      }
    } catch (err: any) {
      console.warn('Google connection error:', err);
      setError(err.message || 'No se pudo conectar con la cuenta de Google. Inténtelo nuevamente.');
    } finally {
      setIsGoogleLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 bg-gradient-to-b from-[#060D1F] via-[#091536] to-[#020617]">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6 sm:p-8 text-slate-900 border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-tr from-slate-900 via-blue-900 to-sky-600 flex items-center justify-center shadow-lg shadow-blue-950/20">
            <span className="text-white font-black text-2xl tracking-tighter">G</span>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-950">
            GEOCIENCES S.A.C.
          </h1>
          <p className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">
            Consultoría e Ingeniería Civil
          </p>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 tracking-wide uppercase">
              Correo Electrónico
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="usuario@geociencias.pe"
              required
              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 outline-none text-sm transition-all bg-slate-50/50"
            />
          </div>

          {/* Password field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 tracking-wide uppercase mb-1">
              Contraseña
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="•••••••••"
                required
                className="w-full pl-4 pr-11 py-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 outline-none text-sm transition-all bg-slate-50/50"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                aria-label={showPassword ? 'Ocultar contraseña' : 'Ver contraseña'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Primary Blue Button */}
          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-sm tracking-wide uppercase shadow-lg shadow-blue-600/25 transition-all transform active:scale-[0.99] flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-5 h-5" />
            INICIAR SESIÓN
          </button>
        </form>

        {/* Divider */}
        <div className="my-5 flex items-center gap-3">
          <div className="flex-1 h-px bg-slate-200" />
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            O AUTENTICACIÓN
          </span>
          <div className="flex-1 h-px bg-slate-200" />
        </div>

        {/* Secondary Button with Red Border: CONECTAR CON GOOGLE */}
        <button
          type="button"
          onClick={handleStartGoogleFlow}
          disabled={isGoogleLoading}
          className="w-full py-3 px-4 rounded-xl border-2 border-red-500 hover:bg-red-50 active:bg-red-100 text-slate-800 font-bold text-xs tracking-wide uppercase transition-all flex items-center justify-center gap-2.5"
        >
          {isGoogleLoading ? (
            <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
          ) : (
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
          )}
          <span>CONECTAR CON GOOGLE</span>
        </button>

        {/* Google Connection Status */}
        {googleConnected && (
          <div className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-emerald-600 font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Cuenta Google conectada y verificada</span>
          </div>
        )}

        {/* Security watermark */}
        <p className="mt-5 text-center text-[10px] text-slate-400">
          Acceso protegido con cifrado SSL/TLS · Servidor Empresarial
        </p>
      </div>

      {/* Google Permission Notification Modal */}
      {showPermissionPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={() => setShowPermissionPrompt(false)}
          />
          <div className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6 text-slate-900 border border-slate-200 z-10 animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <svg className="w-6 h-6 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <h3 className="font-extrabold text-sm text-slate-900 uppercase tracking-wide">
                  Notificación de Permisos
                </h3>
              </div>
              <button
                onClick={() => setShowPermissionPrompt(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <div className="space-y-3 text-xs text-slate-600 mb-5 leading-relaxed">
              <p className="font-semibold text-slate-800">
                Se abrirá la ventana oficial de Google para usar un <strong>correo existente</strong> en tu dispositivo.
              </p>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                <p className="font-bold text-slate-700 uppercase text-[10px] tracking-wider">
                  Permisos requeridos para GEOCIENCES S.A.C.:
                </p>
                <ul className="space-y-1.5 text-[11px]">
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <span><strong>Cuenta y Correo:</strong> Identificación del colaborador de obra.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <span><strong>Google Drive:</strong> Consulta de carpetas técnicas según cargo.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <span><strong>Google Sheets:</strong> Sincronización de cálculos y reportes.</span>
                  </li>
                </ul>
              </div>
              <p className="text-[11px] text-slate-500">
                Al continuar, podrás elegir cualquiera de tus cuentas de Google ya guardadas en tu navegador o celular.
              </p>
            </div>

            {/* Actions */}
            <div className="space-y-2">
              <button
                onClick={executeGoogleSignIn}
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition-all active:scale-[0.98]"
              >
                <span>CONTINUAR A GOOGLE</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => setShowPermissionPrompt(false)}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs uppercase transition-all"
              >
                CANCELAR
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

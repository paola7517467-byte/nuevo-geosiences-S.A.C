import React from 'react';
import { FileSpreadsheet, MapPin, MessageCircle } from 'lucide-react';
import { UserRole } from '../types';
import { WHATSAPP_URL } from '../data/initialData';

interface BottomBarProps {
  role: UserRole;
  activeScreen: string;
  onOpenExcel: () => void;
  onOpenGPS: () => void;
}

export const BottomBar: React.FC<BottomBarProps> = ({
  role,
  activeScreen,
  onOpenExcel,
  onOpenGPS,
}) => {
  const isObrero = role === 'OBRERO';

  const containerBg = isObrero
    ? 'bg-sky-100/95 border-t border-sky-300 text-slate-800'
    : role === 'ADMINISTRADOR'
    ? 'bg-slate-900/95 border-t border-slate-700 text-slate-100'
    : role === 'RESIDENTE'
    ? 'bg-sky-950/95 border-t border-sky-800 text-white'
    : 'bg-neutral-950/95 border-t border-neutral-800 text-white';

  const handleWhatsApp = () => {
    window.open(WHATSAPP_URL, '_blank', 'noopener,noreferrer');
  };

  return (
    <nav className={`fixed bottom-0 left-0 right-0 z-30 shadow-2xl backdrop-blur-md ${containerBg}`}>
      <div className="max-w-md mx-auto grid grid-cols-3 gap-2 px-3 py-2">
        {/* EXCEL */}
        <button
          onClick={onOpenExcel}
          className={`min-h-[52px] flex flex-col items-center justify-center rounded-xl font-bold transition-all active:scale-95 ${
            activeScreen === 'excel'
              ? 'bg-emerald-600 text-white shadow-md'
              : isObrero
              ? 'bg-white hover:bg-sky-50 text-emerald-700 border border-sky-200'
              : 'bg-white/10 hover:bg-white/15 text-emerald-400'
          }`}
        >
          <FileSpreadsheet className="w-5 h-5 mb-0.5" strokeWidth={2.5} />
          <span className="text-xs uppercase tracking-wider">EXCEL</span>
        </button>

        {/* GPS */}
        <button
          onClick={onOpenGPS}
          className={`min-h-[52px] flex flex-col items-center justify-center rounded-xl font-bold transition-all active:scale-95 ${
            activeScreen === 'gps'
              ? 'bg-blue-600 text-white shadow-md'
              : isObrero
              ? 'bg-white hover:bg-sky-50 text-blue-700 border border-sky-200'
              : 'bg-white/10 hover:bg-white/15 text-blue-400'
          }`}
        >
          <MapPin className="w-5 h-5 mb-0.5" strokeWidth={2.5} />
          <span className="text-xs uppercase tracking-wider">GPS</span>
        </button>

        {/* WHATSAPP */}
        <button
          onClick={handleWhatsApp}
          className={`min-h-[52px] flex flex-col items-center justify-center rounded-xl font-bold transition-all active:scale-95 ${
            isObrero
              ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
        >
          <MessageCircle className="w-5 h-5 mb-0.5" strokeWidth={2.5} />
          <span className="text-xs uppercase tracking-wider">WHATSAPP</span>
        </button>
      </div>
    </nav>
  );
};

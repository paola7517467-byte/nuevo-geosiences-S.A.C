import { UserProfile, UserRole, ListItem, SheetRow, GPSRecord, RoleResponsibility } from '../types';
import { INITIAL_ITEMS, INITIAL_SHEET_DATA, ROLE_RESPONSIBILITIES } from '../data/initialData';

const STORAGE_KEYS = {
  USER: 'geosciences_user_profile',
  ITEMS: 'geosciences_role_items',
  SHEETS: 'geosciences_sheets_data',
  GPS: 'geosciences_gps_records',
  RESPONSIBILITIES: 'geosciences_role_responsibilities',
  LAST_SYNC: 'geosciences_last_sync',
};

export const defaultUser: UserProfile = {
  id: 'usr-default',
  email: 'danidaniloacostasamaniego@gmail.com',
  name: 'Ing. Danilo Acosta',
  role: 'GERENTE',
  avatarUrl: '',
  phone: '+51 900 308 983',
  isGoogleConnected: false,
};

export const loadUserProfile = (): UserProfile => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading user profile from storage', e);
  }
  return defaultUser;
};

export const saveUserProfile = (profile: UserProfile): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(profile));
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString());
  } catch (e) {
    console.error('Error saving user profile', e);
  }
};

export const loadRoleItems = (): Record<UserRole, ListItem[]> => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ITEMS);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Ensure all 4 roles exist
      return {
        GERENTE: parsed.GERENTE || INITIAL_ITEMS.GERENTE,
        ADMINISTRADOR: parsed.ADMINISTRADOR || INITIAL_ITEMS.ADMINISTRADOR,
        RESIDENTE: parsed.RESIDENTE || INITIAL_ITEMS.RESIDENTE,
        OBRERO: parsed.OBRERO || INITIAL_ITEMS.OBRERO,
      };
    }
  } catch (e) {
    console.warn('Error loading role items', e);
  }
  return INITIAL_ITEMS;
};

export const saveRoleItems = (items: Record<UserRole, ListItem[]>): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(items));
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString());
  } catch (e) {
    console.error('Error saving role items', e);
  }
};

export const loadSheetData = (): Record<UserRole, SheetRow[]> => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SHEETS);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        GERENTE: parsed.GERENTE || INITIAL_SHEET_DATA.GERENTE,
        ADMINISTRADOR: parsed.ADMINISTRADOR || INITIAL_SHEET_DATA.ADMINISTRADOR,
        RESIDENTE: parsed.RESIDENTE || INITIAL_SHEET_DATA.RESIDENTE,
        OBRERO: parsed.OBRERO || INITIAL_SHEET_DATA.OBRERO,
      };
    }
  } catch (e) {
    console.warn('Error loading sheet data', e);
  }
  return INITIAL_SHEET_DATA;
};

export const saveSheetData = (data: Record<UserRole, SheetRow[]>): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.SHEETS, JSON.stringify(data));
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString());
  } catch (e) {
    console.error('Error saving sheet data', e);
  }
};

export const loadGPSRecords = (): GPSRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GPS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading GPS records', e);
  }
  return [
    {
      id: 'gps-sample-1',
      userId: 'usr-sample',
      userName: 'Carlos Mendoza',
      role: 'GERENTE',
      latitude: -11.9392,
      longitude: -76.7028,
      accuracy: 6.5,
      timestamp: '2026-11-08 14:30:12',
      projectName: 'Carretera Central Km 42 - Chosica',
      notes: 'Marcación de inicio de sondaje SPT-03',
    },
  ];
};

export const saveGPSRecord = (record: GPSRecord): GPSRecord[] => {
  const existing = loadGPSRecords();
  const updated = [record, ...existing];
  try {
    localStorage.setItem(STORAGE_KEYS.GPS, JSON.stringify(updated));
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString());
  } catch (e) {
    console.error('Error saving GPS record', e);
  }
  return updated;
};

export const loadRoleResponsibilities = (): Record<UserRole, RoleResponsibility> => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RESPONSIBILITIES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading role responsibilities', e);
  }
  return ROLE_RESPONSIBILITIES;
};

export const saveRoleResponsibilities = (data: Record<UserRole, RoleResponsibility>): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.RESPONSIBILITIES, JSON.stringify(data));
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString());
  } catch (e) {
    console.error('Error saving responsibilities', e);
  }
};

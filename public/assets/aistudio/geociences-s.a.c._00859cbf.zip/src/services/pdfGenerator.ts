import { jsPDF } from 'jspdf';
import { ListItem, UserRole, GPSRecord } from '../types';

export interface PDFExportOptions {
  reportType?: string;
  customObservations?: string;
  includeGPS?: boolean;
  gpsRecord?: GPSRecord | null;
  includeEmployeeSignature?: boolean;
  signers?: {
    label: string;
    sublabel: string;
  }[];
}

export const buildPDFDocument = (
  item: ListItem,
  role: UserRole,
  currentUserName: string,
  options?: PDFExportOptions
): jsPDF => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 16;
  const contentWidth = pageWidth - margin * 2;

  // 1. Top Header Navy Banner
  doc.setFillColor(15, 23, 42); // Navy Slate (#0F172A)
  doc.rect(margin, 12, contentWidth, 26, 'F');

  // Gold accent stripe
  doc.setFillColor(245, 158, 11); // Gold Amber (#F59E0B)
  doc.rect(margin, 38, contentWidth, 2, 'F');

  // Brand Typography
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(255, 255, 255);
  doc.text('GEOCIENCES S.A.C.', margin + 8, 22);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(203, 213, 225);
  doc.text('CONSULTORÍA GEOTÉCNICA · MECÁNICA DE SUELOS · CONTROL CIVIL', margin + 8, 28);
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text('RUC: 20601234567 · Registro Nacional de Proveedores (RNP)', margin + 8, 33);

  // Document Badge on top right
  const badgeWidth = 46;
  doc.setFillColor(30, 58, 138); // Blue 900
  doc.roundedRect(pageWidth - margin - badgeWidth - 4, 16, badgeWidth, 18, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(255, 255, 255);
  doc.text('REPORTE TÉCNICO', pageWidth - margin - badgeWidth / 2 - 4, 22, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(226, 232, 240);
  doc.text(item.code || 'GEO-DOC-2026', pageWidth - margin - badgeWidth / 2 - 4, 28, { align: 'center' });

  // 2. Report Main Title
  let currentY = 47;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);

  const defaultTitle =
    role === 'ADMINISTRADOR'
      ? 'FICHA TÉCNICA Y EVALUACIÓN DE PERSONAL'
      : role === 'OBRERO'
      ? 'REPORTE OPERATIVO DE CAMPO Y TRABAJOS DE OBRA'
      : 'INFORME DE CONTROL GEOTÉCNICO Y SUPERVISIÓN';

  const reportTitle = options?.reportType || defaultTitle;
  doc.text(reportTitle, margin, currentY);
  currentY += 6;

  // 3. Metadata Information Card
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin, currentY, contentWidth, 38, 2, 2, 'FD');

  const now = new Date();
  const dateFormatted = `${now.toLocaleDateString('es-PE')} ${now.toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit' })}`;

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('REGISTRO / NOMBRE:', margin + 6, currentY + 7);
  doc.text('CÓDIGO DE IDENTIFICACIÓN:', margin + 6, currentY + 15);
  doc.text('CARGO / EMISOR:', margin + 6, currentY + 23);
  doc.text('FECHA DE GENERACIÓN:', margin + 6, currentY + 31);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);

  const displayName = item.name.length > 55 ? item.name.substring(0, 52) + '...' : item.name;
  doc.text(displayName, margin + 54, currentY + 7);
  doc.text(item.code || 'N/A', margin + 54, currentY + 15);
  doc.text(`${role} (${currentUserName})`, margin + 54, currentY + 23);
  doc.text(dateFormatted, margin + 54, currentY + 31);

  // Status tag on right side
  const statusX = pageWidth - margin - 42;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('ESTADO ACTUAL:', statusX, currentY + 15);

  const statusColors: Record<string, [number, number, number]> = {
    activo: [22, 163, 74],
    en_progreso: [2, 132, 199],
    completado: [37, 99, 235],
    pendiente: [217, 119, 6],
  };
  const [r, g, b] = statusColors[item.status] || [71, 85, 105];
  doc.setTextColor(r, g, b);
  doc.setFontSize(9);
  doc.text(item.status.toUpperCase().replace('_', ' '), statusX, currentY + 23);

  currentY += 44;

  // 4. Section 1: Detailed Specifications
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('1. DESCRIPCIÓN TÉCNICA Y ESPECIFICACIONES DE OPERACIÓN', margin, currentY);
  currentY += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(51, 65, 85);
  const splitDetails = doc.splitTextToSize(
    item.details || 'Actividad registrada conforme a los requerimientos de calidad y normas de GEOCIENCES S.A.C.',
    contentWidth - 6
  );
  doc.text(splitDetails, margin + 3, currentY);
  currentY += Math.max(splitDetails.length * 5, 10) + 4;

  // 5. Section 2: Technical Responsibility & Field Location
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('2. UBICACIÓN GEOGRÁFICA Y CONTROL OPERATIVO', margin, currentY);
  currentY += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(51, 65, 85);
  doc.text(`• Frente de Trabajo / Ubicación: ${item.location || 'Frente Principal Obra - Lima'}`, margin + 3, currentY);
  currentY += 5;
  doc.text(`• Responsable Asignado: ${item.responsible || currentUserName}`, margin + 3, currentY);
  currentY += 5;
  doc.text(`• Especialidad Técnica: ${item.category || 'Mecánica de Suelos y Geotecnia'}`, margin + 3, currentY);
  currentY += 5;
  doc.text(`• Sincronización en Nube: ${item.updatedAt}`, margin + 3, currentY);
  currentY += 8;

  // 6. Section 3: GPS Georeference (if enabled or present)
  if (options?.includeGPS && options.gpsRecord) {
    doc.setFillColor(239, 246, 255); // Light Blue
    doc.setDrawColor(191, 219, 254);
    doc.roundedRect(margin, currentY, contentWidth, 18, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 58, 138);
    doc.text('3. COORDENADAS GPS GEODÉSICAS (CAPTURA SATELITAL EN VIVO)', margin + 4, currentY + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(15, 23, 42);
    const gpsText = `Latitud: ${options.gpsRecord.latitude.toFixed(6)}°  |  Longitud: ${options.gpsRecord.longitude.toFixed(6)}°  |  Precisión: ±${options.gpsRecord.accuracy}m  |  Fecha: ${options.gpsRecord.timestamp}`;
    doc.text(gpsText, margin + 4, currentY + 12);
    currentY += 23;
  }

  // 7. Section 4: Observations and SSOMA Recommendations
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('4. OBSERVACIONES Y RECOMENDACIONES TÉCNICO-SSOMA', margin, currentY);
  currentY += 5;

  doc.setFillColor(254, 252, 232); // Amber light
  doc.setDrawColor(253, 230, 138);
  doc.roundedRect(margin, currentY, contentWidth, 22, 2, 2, 'FD');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(120, 53, 15);
  const defaultObs =
    'Documento técnico verificado en cumplimiento con la Norma Técnica G.050 de Seguridad y directrices ASTM de mecánica de suelos. Queda validado y registrado en la base de datos de GEOCIENCES S.A.C.';
  const obsText = options?.customObservations?.trim() || defaultObs;
  const splitObs = doc.splitTextToSize(obsText, contentWidth - 8);
  doc.text(splitObs, margin + 4, currentY + 6);
  currentY += 28;

  // 8. Signatures Section (3 columns or 4 columns)
  const signY = pageHeight - 44;
  const signers = options?.signers || [
    { label: 'GERENCIA GENERAL', sublabel: 'GEOCIENCES S.A.C.' },
    { label: 'RESIDENCIA DE OBRA', sublabel: 'Colegio de Ingenieros (CIP)' },
    { label: 'SUPERVISIÓN SSOMA', sublabel: 'Seguridad y Salud Ocupacional' },
  ];

  const colWidth = contentWidth / signers.length;
  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.4);

  signers.forEach((s, i) => {
    const startX = margin + i * colWidth + 4;
    const endX = margin + (i + 1) * colWidth - 4;
    const centerX = (startX + endX) / 2;

    doc.line(startX, signY, endX, signY);

    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(s.label, centerX, signY + 4, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(s.sublabel, centerX, signY + 8, { align: 'center' });
  });

  // 9. Footer Stripe
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, pageHeight - 14, contentWidth, 5.5, 'F');
  doc.setFontSize(6.5);
  doc.setTextColor(255, 255, 255);
  doc.text(
    'GEOCIENCES S.A.C. · Lima, Perú · RUC: 20601234567 · Sistema Móvil Integrado de Control en Obra',
    pageWidth / 2,
    pageHeight - 10.5,
    { align: 'center' }
  );

  return doc;
};

// Direct mobile download using Blob anchor for robust mobile execution
export const generatePDFReport = (
  item: ListItem,
  role: UserRole,
  currentUserName: string,
  options?: PDFExportOptions
): void => {
  const doc = buildPDFDocument(item, role, currentUserName, options);
  const filename = `GEOCIENCES_${role}_${(item.code || 'DOC').replace(/[^a-zA-Z0-9_-]/g, '_')}_${Date.now()}.pdf`;

  try {
    const blob = doc.output('blob');
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 3000);
  } catch (err) {
    console.warn('Fallback to standard doc.save()', err);
    doc.save(filename);
  }
};

// Generates a consolidated PDF summary of all items in the list
export const generateConsolidatedReport = (
  items: ListItem[],
  role: UserRole,
  currentUserName: string
): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;
  const contentWidth = pageWidth - margin * 2;

  // Navy Banner
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, 12, contentWidth, 24, 'F');
  doc.setFillColor(245, 158, 11);
  doc.rect(margin, 36, contentWidth, 2, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(255, 255, 255);
  doc.text('GEOCIENCES S.A.C.', margin + 8, 22);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(203, 213, 225);
  doc.text(`REPORTE GENERAL CONSOLIDADO - MÓDULO ${role}`, margin + 8, 28);
  doc.text(`RUC: 20601234567 · Fecha de emisión: ${new Date().toLocaleDateString('es-PE')} ${new Date().toLocaleTimeString('es-PE')}`, margin + 8, 33);

  let currentY = 44;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(`REGISTROS ACTIVOS (${items.length} ELEMENTOS)`, margin, currentY);
  currentY += 6;

  // Table header
  doc.setFillColor(30, 41, 59);
  doc.rect(margin, currentY, contentWidth, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(255, 255, 255);

  doc.text('CÓDIGO', margin + 3, currentY + 5.5);
  doc.text('NOMBRE / DESCRIPCIÓN', margin + 32, currentY + 5.5);
  doc.text('UBICACIÓN', margin + 115, currentY + 5.5);
  doc.text('ESTADO', margin + 155, currentY + 5.5);
  currentY += 8;

  // Table rows
  items.forEach((item, index) => {
    if (currentY > pageHeight - 55) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFillColor(index % 2 === 0 ? 255 : 248, index % 2 === 0 ? 255 : 250, index % 2 === 0 ? 255 : 252);
    doc.rect(margin, currentY, contentWidth, 12, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(margin, currentY, contentWidth, 12, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(30, 58, 138);
    doc.text(item.code || `ID-${index + 1}`, margin + 3, currentY + 7);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(15, 23, 42);
    const truncatedName = item.name.length > 46 ? item.name.substring(0, 44) + '...' : item.name;
    doc.text(truncatedName, margin + 32, currentY + 7);

    doc.setTextColor(71, 85, 105);
    const truncatedLoc = (item.location || 'Frente de Obra').substring(0, 22);
    doc.text(truncatedLoc, margin + 115, currentY + 7);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(item.status === 'completado' ? 37 : item.status === 'activo' ? 22 : 217, 99, 235);
    doc.text(item.status.toUpperCase().replace('_', ' '), margin + 155, currentY + 7);

    currentY += 12;
  });

  // Signatures on consolidated
  const signY = pageHeight - 38;
  const colWidth = contentWidth / 2;
  doc.setDrawColor(148, 163, 184);

  doc.line(margin + 10, signY, margin + colWidth - 10, signY);
  doc.line(margin + colWidth + 10, signY, margin + contentWidth - 10, signY);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('GERENCIA GENERAL', margin + colWidth / 2, signY + 4, { align: 'center' });
  doc.text('RESPONSABLE TÉCNICO', margin + colWidth + colWidth / 2, signY + 4, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text('GEOCIENCES S.A.C.', margin + colWidth / 2, signY + 8, { align: 'center' });
  doc.text(currentUserName, margin + colWidth + colWidth / 2, signY + 8, { align: 'center' });

  const filename = `GEOCIENCES_Consolidado_${role}_${Date.now()}.pdf`;
  doc.save(filename);
};

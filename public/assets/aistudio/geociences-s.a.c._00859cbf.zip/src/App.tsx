import React, { useState, useEffect } from 'react';
import { UserRole, UserProfile, ListItem, SheetRow, RoleResponsibility } from './types';
import {
  loadUserProfile,
  saveUserProfile,
  loadRoleItems,
  saveRoleItems,
  loadSheetData,
  saveSheetData,
  loadRoleResponsibilities,
  saveRoleResponsibilities,
} from './services/storage';
import { syncPayloadToCloud, getCloudConfig } from './services/cloudSync';
import { LoginScreen } from './components/LoginScreen';
import { CargoSelectScreen } from './components/CargoSelectScreen';
import { TopBar } from './components/TopBar';
import { BottomBar } from './components/BottomBar';
import { DrawerMenu } from './components/DrawerMenu';
import { RoleDashboard } from './components/RoleDashboard';
import { ExcelModule } from './components/ExcelModule';
import { GPSModule } from './components/GPSModule';
import { ProfileScreen } from './components/ProfileScreen';
import { RoleModal } from './components/RoleModal';
import { ProtocolosModal } from './components/ProtocolosModal';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { CloudSyncModal } from './components/CloudSyncModal';

type ScreenState =
  | 'login'
  | 'cargo_select'
  | 'dashboard'
  | 'excel'
  | 'gps'
  | 'profile'
  | 'rol'
  | 'protocolos';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => loadUserProfile());
  const [activeScreen, setActiveScreen] = useState<ScreenState>('login');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isCloudSyncOpen, setIsCloudSyncOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>(() => {
    const cfg = getCloudConfig();
    return cfg.lastSyncTimestamp
      ? new Date(cfg.lastSyncTimestamp).toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      : 'Reciente';
  });

  // Data states
  const [itemsByRole, setItemsByRole] = useState<Record<UserRole, ListItem[]>>(() => loadRoleItems());
  const [sheetsByRole, setSheetsByRole] = useState<Record<UserRole, SheetRow[]>>(() => loadSheetData());
  const [responsibilitiesByRole, setResponsibilitiesByRole] = useState<Record<UserRole, RoleResponsibility>>(() => loadRoleResponsibilities());

  // Automatic Cloud Sync Helper
  const triggerAutoSync = async (
    action: 'sync_all' | 'sync_items' | 'sync_sheet' | 'sync_profile',
    role: UserRole,
    payload: {
      items?: ListItem[];
      sheets?: SheetRow[];
      profile?: UserProfile;
    }
  ) => {
    setIsSyncing(true);
    try {
      const res = await syncPayloadToCloud(action, role, payload, currentUser.email);
      setLastSyncTime(new Date(res.timestamp).toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } finally {
      setTimeout(() => setIsSyncing(false), 400);
    }
  };

  // Save changes automatically
  const handleUpdateItemName = (id: string, newName: string) => {
    const role = currentUser.role;
    const currentList = itemsByRole[role];
    const updated = currentList.map((it) =>
      it.id === id ? { ...it, name: newName, updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16) } : it
    );
    const updatedAll = { ...itemsByRole, [role]: updated };
    setItemsByRole(updatedAll);
    saveRoleItems(updatedAll);
    triggerAutoSync('sync_items', role, { items: updated });
  };

  const handleAddItem = (newItem: ListItem) => {
    const role = currentUser.role;
    const updated = [newItem, ...itemsByRole[role]];
    const updatedAll = { ...itemsByRole, [role]: updated };
    setItemsByRole(updatedAll);
    saveRoleItems(updatedAll);
    triggerAutoSync('sync_items', role, { items: updated });
  };

  const handleUpdateSheetData = (newData: SheetRow[]) => {
    const role = currentUser.role;
    const updatedAll = { ...sheetsByRole, [role]: newData };
    setSheetsByRole(updatedAll);
    saveSheetData(updatedAll);
    triggerAutoSync('sync_sheet', role, { sheets: newData });
  };

  const handleSaveProfile = (updated: UserProfile) => {
    setCurrentUser(updated);
    saveUserProfile(updated);
    triggerAutoSync('sync_profile', updated.role, { profile: updated });
  };

  const handleSaveResponsibility = (updated: RoleResponsibility) => {
    const role = currentUser.role;
    const updatedAll = { ...responsibilitiesByRole, [role]: updated };
    setResponsibilitiesByRole(updatedAll);
    saveRoleResponsibilities(updatedAll);
  };

  const handleForceSyncAll = async () => {
    setIsSyncing(true);
    try {
      const role = currentUser.role;
      const res = await syncPayloadToCloud(
        'sync_all',
        role,
        {
          items: itemsByRole[role],
          sheets: sheetsByRole[role],
          profile: currentUser,
        },
        currentUser.email
      );
      setLastSyncTime(new Date(res.timestamp).toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } finally {
      setTimeout(() => setIsSyncing(false), 500);
    }
  };

  const handleLoginSuccess = (email: string, isGoogle: boolean, name?: string, photoURL?: string) => {
    const updated: UserProfile = {
      ...currentUser,
      email,
      name: name || currentUser.name,
      avatarUrl: photoURL || currentUser.avatarUrl,
      isGoogleConnected: isGoogle,
    };
    setCurrentUser(updated);
    saveUserProfile(updated);
    setActiveScreen('cargo_select');
  };

  const handleRoleSelect = (selectedRole: UserRole) => {
    const updated: UserProfile = {
      ...currentUser,
      role: selectedRole,
    };
    setCurrentUser(updated);
    saveUserProfile(updated);
    setActiveScreen('dashboard');
  };

  const handleLogout = () => {
    setActiveScreen('login');
    setIsDrawerOpen(false);
  };

  // Screen 1: LOGIN ONLY
  if (activeScreen === 'login') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col font-sans">
        <LoginScreen onSuccess={handleLoginSuccess} currentUser={currentUser} />
      </div>
    );
  }

  // Screen 2: CARGO SELECTION ONLY
  if (activeScreen === 'cargo_select') {
    return (
      <div className="min-h-screen bg-black flex flex-col font-sans">
        <CargoSelectScreen
          onSelectRole={handleRoleSelect}
          currentUser={currentUser}
          onBackToLogin={() => setActiveScreen('login')}
        />
      </div>
    );
  }

  // Screen: EXCEL ONLY
  if (activeScreen === 'excel') {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col font-sans">
        <ExcelModule
          role={currentUser.role}
          data={sheetsByRole[currentUser.role] || []}
          onUpdateData={handleUpdateSheetData}
          onBack={() => setActiveScreen('dashboard')}
        />
      </div>
    );
  }

  // Screen: GPS ONLY
  if (activeScreen === 'gps') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col font-sans">
        <GPSModule
          role={currentUser.role}
          currentUser={currentUser}
          onBack={() => setActiveScreen('dashboard')}
        />
      </div>
    );
  }

  // Screen: PROFILE ONLY
  if (activeScreen === 'profile') {
    return (
      <div className="min-h-screen bg-white flex flex-col font-sans">
        <ProfileScreen
          user={currentUser}
          onSaveProfile={handleSaveProfile}
          onBack={() => setActiveScreen('dashboard')}
        />
      </div>
    );
  }

  // Screen: ROL ONLY
  if (activeScreen === 'rol') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col font-sans">
        <RoleModal
          role={currentUser.role}
          data={responsibilitiesByRole[currentUser.role]}
          onSave={handleSaveResponsibility}
          onBack={() => setActiveScreen('dashboard')}
        />
      </div>
    );
  }

  // Screen: PROTOCOLOS ONLY
  if (activeScreen === 'protocolos') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col font-sans">
        <ProtocolosModal
          role={currentUser.role}
          onBack={() => setActiveScreen('dashboard')}
        />
      </div>
    );
  }

  // Screen 3: MAIN ROLE DASHBOARD
  return (
    <div className="min-h-screen flex flex-col font-sans relative select-none">
      <PWAInstallBanner />

      {/* Fixed Top Bar */}
      <TopBar
        role={currentUser.role}
        onOpenMenu={() => setIsDrawerOpen(true)}
        onGoHome={() => setActiveScreen('dashboard')}
        onOpenCloudSync={() => setIsCloudSyncOpen(true)}
        isSyncing={isSyncing}
      />

      {/* Sliding Drawer Menu */}
      <DrawerMenu
        isOpen={isDrawerOpen}
        role={currentUser.role}
        user={currentUser}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={(screen) => setActiveScreen(screen)}
        onOpenCloudSync={() => setIsCloudSyncOpen(true)}
        onLogout={handleLogout}
      />

      {/* Central Role Dashboard */}
      <main className="flex-1 w-full">
        <RoleDashboard
          role={currentUser.role}
          items={itemsByRole[currentUser.role] || []}
          currentUser={currentUser}
          onUpdateItemName={handleUpdateItemName}
          onAddItem={handleAddItem}
        />
      </main>

      {/* Fixed Bottom Bar */}
      <BottomBar
        role={currentUser.role}
        activeScreen={activeScreen}
        onOpenExcel={() => setActiveScreen('excel')}
        onOpenGPS={() => setActiveScreen('gps')}
      />

      {/* Cloud Sync & Google Drive Modal */}
      <CloudSyncModal
        isOpen={isCloudSyncOpen}
        role={currentUser.role}
        user={currentUser}
        onClose={() => setIsCloudSyncOpen(false)}
        onForceSync={handleForceSyncAll}
        isSyncing={isSyncing}
        lastSyncTime={lastSyncTime}
      />
    </div>
  );
}

export type UserRole = 'GERENTE' | 'ADMINISTRADOR' | 'RESIDENTE' | 'OBRERO';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatarUrl: string;
  dni?: string;
  phone?: string;
  isGoogleConnected?: boolean;
}

export interface ListItem {
  id: string;
  name: string;
  code: string;
  role: UserRole;
  status: 'activo' | 'en_progreso' | 'completado' | 'pendiente';
  category: string;
  details: string;
  updatedAt: string;
  location?: string;
  responsible?: string;
}

export interface SheetColumn {
  key: string;
  label: string;
  type?: 'text' | 'number' | 'date' | 'select';
  options?: string[];
  width?: string;
}

export interface SheetRow {
  id: string;
  [key: string]: string | number;
}

export interface GPSRecord {
  id: string;
  userId: string;
  userName: string;
  role: UserRole;
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: string;
  projectName?: string;
  notes?: string;
}

export interface RoleResponsibility {
  role: UserRole;
  title: string;
  summary: string;
  responsibilities: string[];
  lastUpdated: string;
}
